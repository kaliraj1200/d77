<?php
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "fireworks_store");
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Ensure 'images' directory exists
$uploadDir = __DIR__ . "/images/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Add Product
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_product'])) {
    $name = trim($_POST['name']);
    $price = trim($_POST['price']);
    $type = trim($_POST['type']);
    $stock = trim($_POST['stock']);

    if (!empty($_FILES['image']['name'])) {
        $imageName = time() . "_" . basename($_FILES['image']['name']);
        $targetFile = $uploadDir . $imageName;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $imagePath = "images/" . $imageName;
        } else {
            die("Error: File upload failed.");
        }
    } else {
        die("Error: Image is required.");
    }

    $stmt = $conn->prepare("INSERT INTO products (name, price, type, image, stock) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sissi", $name, $price, $type, $imagePath, $stock);

    if ($stmt->execute()) {
        echo "<script>alert('Product added successfully!'); window.location.href='admin_products.php';</script>";
    } else {
        die("Error: " . $stmt->error);
    }
    $stmt->close();
}

// Delete Product
if (isset($_GET['delete_id'])) {
    $id = $_GET['delete_id'];

    $result = $conn->query("SELECT image FROM products WHERE id='$id'");
    $row = $result->fetch_assoc();

    if ($row) {
        unlink(__DIR__ . "/" . $row['image']);
    }

    $conn->query("DELETE FROM products WHERE id='$id'");
    echo "<script>alert('Product deleted successfully!'); window.location.href='admin_products.php';</script>";
}

// Add to stock logic
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_stock'])) {
    $product_id = $_POST['product_id'];
    $add_stock = $_POST['stock_to_add'];

    $conn->query("UPDATE products SET stock = stock + $add_stock WHERE id = $product_id");
    echo "<script>alert('Stock updated successfully!'); window.location.href='admin_products.php';</script>";
}

// Fetch products
$products = $conn->query("SELECT * FROM products ORDER BY id DESC");
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Products</title>
    <link rel="stylesheet" href="css/admin_products.css">

    <style>
    .btn {
        display: inline-block;
        padding: 8px 12px;
        margin: 3px;
        border: none;
        border-radius: 5px;
        color: #fff;
        text-decoration: none; /* Removes underline for <a> */
        cursor: pointer;
        transition: transform 0.2s ease, background 0.3s;
        font-size: 14px;
        font-weight: bold;
    }
    .btn:hover {
        transform: scale(1.05);
    }
    .delete-btn {
        background: #e74c3c;
    }
    .delete-btn:hover {
        background: #c0392b;
    }
    .stock-btn {
        background: #27ae60;
    }
    .stock-btn:hover {
        background: #1e8449;
    }
</style>


    <script>
        function addStock(id) {
            const qty = prompt("Enter stock quantity to add:");
            if (qty !== null && qty > 0) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'admin_products.php';

                const input1 = document.createElement('input');
                input1.type = 'hidden';
                input1.name = 'product_id';
                input1.value = id;

                const input2 = document.createElement('input');
                input2.type = 'hidden';
                input2.name = 'stock_to_add';
                input2.value = qty;

                const input3 = document.createElement('input');
                input3.type = 'hidden';
                input3.name = 'add_stock';
                input3.value = '1';

                form.appendChild(input1);
                form.appendChild(input2);
                form.appendChild(input3);

                document.body.appendChild(form);
                form.submit();
            }
        }
    </script>
</head>

<body>

    <button onclick="window.location.href='admin_page.php'">⬅ Go Back to Admin Panel</button>

    <h2>Manage Products</h2>

    <form method="POST" enctype="multipart/form-data">
        <label>Product Name:</label>
        <input type="text" name="name" required>

        <label>Price:</label>
        <input type="number" name="price" required>

        <label>Type:</label>
        <select name="type" required>
            <option value="" disabled selected>Select type</option>
            <option value="Rockets">Rockets</option>
            <option value="Sparklers">Sparklers</option>
            <option value="Bombs">Bombs</option>
            <option value="Fountains">Fountains</option>
            <option value="Chakris">Chakris</option>
        </select>

        <label>Stock Quantity:</label>
        <input type="number" name="stock" required>

        <label>Image:</label>
        <input type="file" name="image" required>

        <button type="submit" name="add_product">Add Product</button>
    </form>

    <h3>Product List</h3>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Price</th>
            <th>Type</th>
            <th>Stock</th>
            <th>Image</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $products->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td>₹<?= $row['price'] ?></td>
            <td><?= htmlspecialchars($row['type']) ?></td>
            <td><?= $row['stock'] ?></td>
            <td><img src="<?= $row['image'] ?>" width="100"></td>
            <td>
                <button class="btn stock-btn" onclick="addStock(<?= $row['id'] ?>)">➕ Add Stock</button>
                <a class="btn delete-btn" href="admin_products.php?delete_id=<?= $row['id'] ?>" onclick="return confirm('Are you sure?')">🗑 Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

</body>

</html>
