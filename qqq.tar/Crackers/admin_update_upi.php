<?php
session_start();
require 'config.php';

// Fetch existing UPI details
$upiData = null;
try {
    $stmt = $conn->query("SELECT * FROM upi_details ORDER BY updated_at DESC LIMIT 1");
    $upiData = $stmt->fetch_assoc();
} catch (Exception $e) {
    die("Database error: " . $e->getMessage());
}

// Handle UPI Update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $upi_id = $_POST['upi_id'];
    $receiver_name = $_POST['receiver_name'];

    try {
        $stmt = $conn->prepare("INSERT INTO upi_details (upi_id, receiver_name) VALUES (?, ?) 
                               ON DUPLICATE KEY UPDATE upi_id=VALUES(upi_id), receiver_name=VALUES(receiver_name)");
        if ($stmt->execute([$upi_id, $receiver_name])) {
            $_SESSION['message'] = "✅ UPI details updated successfully!";
            $_SESSION['msg_type'] = "success";
        } else {
            $_SESSION['message'] = "❌ Failed to update UPI details.";
            $_SESSION['msg_type'] = "error";
        }
    } catch (Exception $e) {
        $_SESSION['message'] = "Database error: " . $e->getMessage();
        $_SESSION['msg_type'] = "error";
    }

    // Redirect to avoid form resubmission
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Retrieve message from session (if exists)
$message = $_SESSION['message'] ?? "";
$msg_type = $_SESSION['msg_type'] ?? "";
unset($_SESSION['message'], $_SESSION['msg_type']); // Clear message after displaying
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Update UPI</title>
    <style>
        /* General Page Styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Main Container */
        .container {
            background: #fff;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
        }

        /* Heading */
        h1 {
            font-size: 24px;
            margin-bottom: 15px;
            color: #333;
            text-align: center;
        }

        /* Message Box */
        .message {
            font-size: 14px;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 10px;
        }
        .success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }

        /* Form Styling */
        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
            text-align: left;
        }

        /* Label Styling */
        label {
            font-size: 16px;
            font-weight: bold;
        }

        /* Input Fields */
        input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        /* Button */
        button {
            background-color: #007BFF;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }

        button:hover {
            background-color: #0056b3;
        }

        /* Back Link */
        .back-link {
            display: block;
            margin-top: 15px;
            text-decoration: none;
            color: #007BFF;
            font-weight: bold;
            text-align: center;
        }

        .back-link:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Update UPI Payment Details</h1>

        <?php if (!empty($message)): ?>
            <p class="message <?= $msg_type; ?>"><?= htmlspecialchars($message); ?></p>
        <?php endif; ?>

        <form method="post">
            <label for="upi_id">UPI ID:</label>
            <input type="text" id="upi_id" name="upi_id" value="<?= htmlspecialchars($upiData['upi_id'] ?? '') ?>" required>

            <label for="receiver_name">Receiver Name:</label>
            <input type="text" id="receiver_name" name="receiver_name" value="<?= htmlspecialchars($upiData['receiver_name'] ?? '') ?>" required>

            <button type="submit">Update</button>
        </form>

        <a class="back-link" href="admin_page.php">⬅ Back to Dashboard</a>
    </div>
</body>
</html>
