<?php
session_start();
require 'config.php';
require('fpdf.php'); // Include FPDF library

// Check database connection
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Get UTR number from request
$utr_number = $_GET['utr'] ?? '';
if (empty($utr_number)) {
    die("UTR number is missing.");
}

// Fetch order details using UTR
$stmt = $conn->prepare("SELECT * FROM orders WHERE transaction_id = ?");
if (!$stmt) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("s", $utr_number);
$stmt->execute();
$result = $stmt->get_result();
$order = $result->fetch_assoc();

if (!$order) {
    die("Order not found for UTR: " . htmlspecialchars($utr_number));
}

// Order details
$name = $order['name'];
$phone = $order['phone'];
$date = date("d-m-Y H:i:s");
$items = json_decode($order['items'], true);

// Generate Bill Number (Example: Order ID + Date)
$bill_number = "BILL-" . $order['id'] . "-" . date("dmY");

// Create PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Header
$pdf->Cell(0, 10, 'Invoice', 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, "Bill No: $bill_number", 0, 1);
$pdf->Cell(0, 10, "Date: $date", 0, 1);
$pdf->Cell(0, 10, "Customer: $name", 0, 1);
$pdf->Cell(0, 10, "Phone: $phone", 0, 1);
$pdf->Cell(0, 10, "UTR Number: $utr_number", 0, 1);

// Table Header
$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(80, 10, "Product", 1);
$pdf->Cell(30, 10, "Quantity", 1);
$pdf->Cell(40, 10, "Subtotal", 1);
$pdf->Ln();

// Table Data
$pdf->SetFont('Arial', '', 12);
$total = 0;
if (is_array($items)) {
    foreach ($items as $item) {
        $product_name = $item['name'] ?? 'Unknown Product';
        $quantity = $item['quantity'] ?? 0;
        $price = $item['price'] ?? 0; // fallback to 0 if price key is missing
        $subtotal = $quantity * $price;
        $total += $subtotal;

        $pdf->Cell(80, 10, $product_name, 1);
        $pdf->Cell(30, 10, $quantity, 1);
        $pdf->Cell(40, 10, "₹" . number_format($subtotal, 2), 1);
        $pdf->Ln();
    }
} else {
    $pdf->Cell(0, 10, "No products found in this order.", 1, 1);
}

// Total
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(110, 10, "Total Amount", 1);
$pdf->Cell(40, 10, "₹" . number_format($total, 2), 1);
$pdf->Ln(20);

// Thank You Message
$pdf->SetFont('Arial', 'I', 12);
$pdf->Cell(0, 10, "Thank you for shopping with us!", 0, 1, 'C');

// Output PDF
$pdf->Output('D', "Invoice_$bill_number.pdf");
?>
