<?php
require 'config.php';

// Fetch all orders
$result = $conn->query("SELECT * FROM orders ORDER BY created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Orders</title>
    <link rel="stylesheet" href="Css/admin.css">
    <style>
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #4CAF50;
            padding: 10px;
            color: white;
        }
        .top-bar button {
            padding: 8px 15px;
            background: #ff5722;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
        }
        .top-bar button:hover {
            background: #e64a19;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid black;
            padding: 10px;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="top-bar">
    <button onclick="window.location.href='admin_page.php'">Go Back to Admin Page</button>
</div>

<h1>Orders List</h1>

<?php if (isset($_SESSION['order_success'])): ?>
    <p style="color: green;">Order placed successfully!</p>
    <?php unset($_SESSION['order_success']); ?>
<?php endif; ?>

<table>
    <tr>
        <th>Name</th>
        <th>Phone</th>
        <th>Items</th>
        <th>Original Total</th>
        <th>Discount Applied</th>
        <th>Final Amount</th>
        <th>Transaction ID</th>
        <th>Order Placed On</th> <!-- Added Order Date Column -->
    </tr>
    <?php while ($row = $result->fetch_assoc()) { 
        $original_total = floatval($row['total_amount']);
        $discount = ($original_total >= 10000) ? $original_total * 0.50 : 0;
        $final_total = $original_total - $discount;
        $order_date = date("Y-m-d H:i:s", strtotime($row['created_at'])); // Format the order date
    ?>
        <tr>
            <td><?= htmlspecialchars($row['name']); ?></td>
            <td><?= htmlspecialchars($row['phone']); ?></td>
            <td>
                <?php 
                $items = json_decode($row['items'], true);
                if (is_array($items)) {
                    foreach ($items as $item) {
                        echo htmlspecialchars($item['name']) . " (Qty: " . htmlspecialchars($item['quantity']) . ")<br>";
                    }
                } else {
                    echo "Invalid item data";
                }
                ?>
            </td>
            <td>₹<?= number_format($original_total, 2); ?></td>
            <td>₹<?= number_format($discount, 2); ?></td>
            <td><strong>₹<?= number_format($final_total, 2); ?></strong></td>
            <td><?= htmlspecialchars($row['transaction_id']); ?></td>
            <td><?= $order_date; ?></td> <!-- Displaying Order Date -->
        </tr>
    <?php } ?>
</table>

</body>
</html>
