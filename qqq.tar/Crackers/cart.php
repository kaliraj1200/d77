<?php
session_start();
require 'config.php';

// Initialize cart session if not set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Function to calculate total
function calculateTotal()
{
    $total = 0;
    foreach ($_SESSION['cart'] as $item) {
        $total += $item['price'] * $item['quantity'];
    }
    return $total;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['action'])) {
    $action = $_POST['action'];
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;

    if ($action === "add" && $product_id > 0) {
        $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();

        if ($product) {
            if (!isset($_SESSION['cart'][$product_id])) {
                $_SESSION['cart'][$product_id] = [
                    "id" => $product_id,
                    "name" => $product['name'],
                    "price" => floatval($product['price']),
                    "quantity" => $quantity
                ];
            } else {
                $_SESSION['cart'][$product_id]['quantity'] += $quantity;
            }
        }
    } elseif ($action === "update" && $product_id > 0) {
        if (isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id]['quantity'] = $quantity;
        }
    } elseif ($action === "remove" && $product_id > 0) {
        unset($_SESSION['cart'][$product_id]);
    } elseif ($action === "clear") {
        $_SESSION['cart'] = [];
    } elseif ($action === "fetch") {
        echo json_encode([
            "success" => true,
            "items" => array_values($_SESSION['cart']),
            "total" => calculateTotal(),
            "itemCount" => count($_SESSION['cart'])
        ]);
        exit;
    }

    echo json_encode([
        "success" => true,
        "total" => calculateTotal(),
        "itemCount" => count($_SESSION['cart'])
    ]);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="css/cart.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <header class="header">
        <h1>Your Cart</h1>
        <a href="product.php" class="back-button">Back to Product Page</a>
    </header>

    <main>
        <table class="cart-table">
            <thead>
                <tr>
                    <th>Product Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="cart-body">
                <tr><td colspan="5">Loading cart...</td></tr>
            </tbody>
        </table>
        <h3>Subtotal: ₹<span id="subtotal">0.00</span></h3>
        <div class="actions">
            <button class="clear-cart">Clear Cart</button>
            <button class="checkout">Checkout</button>
        </div>
    </main>
<style>
    /* General Styling */
body {
  font-family: 'Arial', sans-serif;
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  background-color: #FAFAFA; /* Light Neutral */
  color: #333333; /* Charcoal Gray */
}

/* Header */
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #990000; /* Crimson Red */
  color: white;
  padding: 15px 20px;
}

.header h1 {
  margin: 0;
}

.header .back-button {
  background-color: #990000; /* Crimson Red */
  color: white;
  border: none;
  padding: 10px 15px;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.header .back-button:hover {
  background-color: #7A0000; /* Darker Crimson */
}

/* Table Styling */
.cart-table {
  width: 90%;
  margin: 20px auto;
  border-collapse: collapse;
  text-align: center;
  background-color: white;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.08); /* Softer shadow */
}

.cart-table th, .cart-table td {
  padding: 15px;
  border: 1px solid #E0E0E0; /* Light Gray border */
}

.cart-table th {
  background-color: #FF7F11; /* Vibrant Orange */
  color: white;
}

.cart-table tr:nth-child(even) {
  background-color: #F0F0F0; /* Soft Light Gray */
}

/* Buttons */
button {
  padding: 8px 12px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.2s ease;
}

button:hover {
  transform: scale(1.05);
}

.quantity-btn {
  background-color: #FF7F11; /* Vibrant Orange */
  color: white;
}

.quantity-btn:hover {
  background-color: #E66E00; /* Darker Orange */
}

.remove-btn {
  background-color: #990000; /* Crimson Red */
  color: white;
}

.remove-btn:hover {
  background-color: #7A0000; /* Darker Crimson */
}

.clear-cart {
  background-color: #9E9E9E; /* Medium Gray */
  color: white;
}

.clear-cart:hover {
  background-color: #616161; /* Darker Gray */
}

.checkout {
  background-color: #FF7F11; /* Vibrant Orange */
  color: white;
}

.checkout:hover {
  background-color: #E66E00; /* Darker Orange */
}

/* Actions Container */
.actions {
  text-align: center;
  margin: 20px;
}

/* Responsive Design */
@media (max-width: 768px) {
  .cart-table {
    font-size: 14px;
  }

  .header {
    flex-direction: column;
    text-align: center;
  }

  .header .back-button {
    margin-top: 10px;
  }
}

</style>
    <script>
    $(document).ready(function () {
        function loadCart() {
            $.post("cart.php", { action: "fetch" }, function (response) {
                if (response.success) {
                    $("#subtotal").text(response.total.toFixed(2));
                    $("#cart-body").html("");
                    if (response.itemCount === 0) {
                        $("#cart-body").html('<tr><td colspan="5">Your cart is empty!</td></tr>');
                    } else {
                        $.each(response.items, function (index, item) {
                            $("#cart-body").append(`
                                <tr id="cart-item-${item.id}">
                                    <td>${item.name}</td>
                                    <td>₹${item.price.toFixed(2)}</td>
                                    <td><input type="number" value="${item.quantity}" class="update-quantity" data-id="${item.id}" min="1"></td>
                                    <td>₹${(item.price * item.quantity).toFixed(2)}</td>
                                    <td><button class="remove-item" data-id="${item.id}">Remove</button></td>
                                </tr>
                            `);
                        });
                    }
                }
            }, "json");
        }

        $(document).on("change", ".update-quantity", function () {
            let productId = $(this).data("id");
            let quantity = $(this).val();
            $.post("cart.php", { action: "update", product_id: productId, quantity }, loadCart, "json");
        });

        $(document).on("click", ".remove-item", function () {
            let productId = $(this).data("id");
            $.post("cart.php", { action: "remove", product_id: productId }, loadCart, "json");
        });

        $(".clear-cart").click(() => $.post("cart.php", { action: "clear" }, loadCart, "json"));

        $(".checkout").click(() => window.location.href = 'userdetails.php');

        loadCart();
    });
    </script>
</body>
</html>