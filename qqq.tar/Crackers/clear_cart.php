<?php
session_start();

// Clear the cart after payment success
unset($_SESSION['cart']);

echo "Cart Cleared";
?>
