CREATE TABLE settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    shop_name VARCHAR(255) NOT NULL,
    address TEXT NOT NULL,
    phone VARCHAR(20) NOT NULL,
    footer_text TEXT NOT NULL
);

INSERT INTO settings (shop_name, address, phone, footer_text) VALUES 
("SIVAMADHU CRACKERS", "44/35, BHARATHI NAGAR 2, SATTUR ROAD, SIVAKASI.", "9489688106", "&copy; " . date("Y") . " SivaMadhu Cracker Shop. All rights reserved.");
------------------------------------
CREATE TABLE slideshow (
    id INT AUTO_INCREMENT PRIMARY KEY,
    image VARCHAR(255) NOT NULL
);

INSERT INTO slideshow (image) VALUES 
("IMG/d--1.webp"), ("IMG/d--2.webp"), ("IMG/d--3.webp");
-------------------------------------------



-- Create the admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

INSERT INTO admin_users (username, password) 
VALUES ('admin', MD5('1234'));

USE fireworks_store;

CREATE TABLE IF NOT EXISTS visitor_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(50) NOT NULL,
    visit_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


---------------------------------------------working------------------------------

CREATE TABLE IF NOT EXISTS settings (
    id INT(11) PRIMARY KEY,
    shop_name VARCHAR(255) NOT NULL,
    address TEXT,
    phone VARCHAR(20) NOT NULL,
    footer_text TEXT
);
INSERT INTO settings (id, shop_name, address, phone, footer_text) 
VALUES (1, 'My Shop', '123 Main St', '9876543210', 'Welcome to our store!')
ON DUPLICATE KEY UPDATE shop_name=VALUES(shop_name), address=VALUES(address), phone=VALUES(phone), footer_text=VALUES(footer_text);
--------------------------------------------------product-----------------------------
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    image VARCHAR(255) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    type VARCHAR(100) NOT NULL
);
<!-------->
ALTER TABLE products ADD stock INT DEFAULT 0;

--------------------------------------------------------------------user----------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullName VARCHAR(255) NOT NULL,
    cityVillage VARCHAR(255) NOT NULL,
    district VARCHAR(255) NOT NULL,
    pincode VARCHAR(6) NOT NULL,
    phone VARCHAR(10) NOT NULL,
    area VARCHAR(255) NOT NULL,
    building VARCHAR(255) NOT NULL,
    landmark VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
=----------------------------------------------------vis
CREATE TABLE visitors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45),
    visit_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO visitors (ip_address) VALUES ('<visitor_ip>');
----------------------------------------------------pay-------------------
CREATE TABLE upi_details (
    id INT AUTO_INCREMENT PRIMARY KEY,
    upi_id VARCHAR(50) NOT NULL,
    receiver_name VARCHAR(100) NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    


);
--------------------------------------------------------------------order---
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    items TEXT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    transaction_id VARCHAR(20) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
