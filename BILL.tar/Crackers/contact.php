<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
    $message = htmlspecialchars($_POST['message']);
    
   
    $to = "madhucrackers@gmail.com";
    $subject = "Contact Form Submission from $name";
    $body = "Name: $name\nEmail: $email\nPhone: $phone\nMessage: $message";
    $headers = "From: $email";
    
    if (mail($to, $subject, $body, $headers)) {
        $feedback = "Thank you for reaching out! We will get back to you soon.";
    } else {
        $feedback = "Sorry, something went wrong. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cracker Shop - Home</title>
  <link rel="stylesheet" href="Css/contacts1.css">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
</head>
<header class="header">
    <nav class="nav">
        <a href="index.php">Home</a>
        <a href="product.php">Product</a>
        <a href="checkout.php">Cart</a>
        <a href="price.php">Price List</a>
        <a href="about.php">About</a>
    </nav>
<body>
  <style>
   

* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: 'Arial', sans-serif;
}

body {
  background: #f9f9f9;
  color: #333333; 
}

.header {
  background: #990000;
  padding: 15px 30px;
}

.nav {
  display: flex;
  justify-content: flex-end;
  gap: 30px;
  flex-wrap: wrap;
}

.nav a {
  color: #fff;
  text-decoration: none;
  font-weight: bold;
  transition: 0.3s;
}

.nav a:hover {
  color: #FF7F11; 
}

.contact-section {
  padding: 50px 20px;
  max-width: 1200px;
  margin: auto;
}

.contact-section h1 {
  text-align: center;
  margin-bottom: 30px;
  font-size: 2.5rem;
  color: white; 
}

.contact-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 20px;
  margin-bottom: 40px;
}

.contact-box {
  background: #fff;
  padding: 20px;
  border-radius: 10px;
  flex: 1 1 30%;
  min-width: 260px;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
  text-align: center;
}

.contact-box .icon i {
  font-size: 2rem;
  color: #990000;
  margin-bottom: 10px;
}

.contact-box h3 {
  margin-bottom: 10px;
  color: #990000;
}

.contact-box p, .contact-box a {
  color: #555;
  text-decoration: none;
  font-size: 0.95rem;
}

.social-media {
  text-align: center;
  margin-bottom: 30px;
}

.social-media h3 {
  margin-bottom: 10px;
  color: #990000;
}

.social-icons a {
  display: inline-block;
  margin: 0 10px;
  color: #990000;
  font-size: 1.5rem;
  transition: 0.3s;
}

.social-icons a:hover {
  color: #FF7F11;
}

.contact-form {
  background: #fff;
  padding: 30px;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
  max-width: 600px;
  margin: auto;
  margin-bottom: 40px;
}

.contact-form input,
.contact-form textarea {
  width: 100%;
  padding: 12px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.contact-form button {
  width: 100%;
  padding: 12px;
  background: #990000;
  color: #fff;
  border: none;
  border-radius: 5px;
  font-weight: bold;
  cursor: pointer;
  transition: 0.3s;
}

.contact-form button:hover {
  background: #FF7F11;
  color: #fff;
}

.feedback {
  text-align: center;
  margin: 20px auto;
  padding: 15px;
  max-width: 500px;
  background: #ffe9e9;
  border: 1px solid #990000;
  color: #990000; 
  border-radius: 5px;
}

.map iframe {
  width: 100%;
  border: none;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

footer {
  background: #990000;
  color: #fff;
  padding: 15px 0;
  text-align: center;
  font-size: 0.9rem;
}


@media (max-width: 768px) {
  .contact-container {
    flex-direction: column;
    align-items: center;
  }

  .nav {
    justify-content: center;
    gap: 20px;
  }
}

  </style>
  <div class="contact-section">
    <h1>Contact Us</h1>
    <div class="contact-container">
      <div class="contact-box">
        <div class="icon"><i class="fas fa-map-marker-alt"></i></div>
        <div class="details">
          <h3>Address</h3>
          <p>3/137/3, R.S.R. Petrol Pump Backside,<br>
             Sattur Road, Sivakasi.</p>
        </div>
      </div>
      <div class="contact-box">
        <div class="icon"><i class="fas fa-phone"></i></div>
        <div class="details">
          <h3>Phones</h3>
          <p>Mobile: +91-94896 88106</p>
          <p>Mobile: +91-7904839872</p>
        </div>
      </div>
      <div class="contact-box">
        <div class="icon"><i class="fas fa-envelope"></i></div>
        <div class="details">
          <h3>Email Address</h3>
          <p>Support:<br>
             Website: <a href="https://madhucrackerssivakasi.com/" target="_blank"></a>
          </p>
        </div>
      </div>
    </div>
    <div class="social-media">
      <h3>Follow Us</h3>
      <div class="social-icons">
        <a href="https://www.facebook.com/people/Madhu-Crackers/pfbid02H6WdnQrYz3gw76kSQ21j3qh6K6MANTcijroYCtpthiZL9VFEmhYWBF2HLepZLCD7l/?mibextid=qi2Omg&rdid=E6wsAsEjvAxXWRaz&share_url=https%3A%2F%2Fwww.facebook.com%2Fshare%2FPLXjoq4Dbu2hbSjf%2F%3Fmibextid%3Dqi2Omg" target="_blank"><i class="fab fa-facebook-f"></i></a>
        <a href="https://www.instagram.com/madhucrackers.sivakasi/?igsh=ZG00cjh4cXFlYzJ5" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="https://www.youtube.com/@madhucrackers-sivakasi" target="_blank"><i class="fab fa-youtube"></i></a>
      </div>
    </div>

    
    
    <!-- Display feedback message if form is submitted -->
    <?php if (isset($feedback)): ?>
      <div class="feedback"><?php echo $feedback; ?></div>
    <?php endif; ?>

    <div class="contact-form">
      <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="tel" name="phone" placeholder="Phone" required>
        <textarea name="message" placeholder="Message" required></textarea>
        <button type="submit">Send Now</button>
      </form>
    </div>

    <div class="map">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3912.5551368051515!2d77.79549581521921!3d9.455536993223007!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b044d034b3918cb%3A0xe31c8c0b1b43bf39!2sRamsons%20Fireworks!5e0!3m2!1sen!2sin!4v1690184293974!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
    </div>
  </div>
  
  <footer><center> 2010-2024 Madhu Crackers. All Rights Reserved</center></footer>
</body>
</html>
