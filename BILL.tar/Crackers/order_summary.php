<?php
session_start();
require 'config.php';

// Include PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

function cleanNumber($num) {
    if (!isset($num) || !is_numeric($num)) return 0;
    return preg_replace('/[^0-9.]/', '', (string)$num) ?: 0;
}

if (!$conn->ping()) {
    $conn->close();
    $conn = new mysqli("localhost", "username", "password", "database_name");
    if ($conn->connect_error) die("Database connection failed: " . $conn->connect_error);
}

$conn->query("SET SESSION wait_timeout = 28800");
$conn->query("SET SESSION interactive_timeout = 28800");

$cart = $_SESSION['cart'] ?? [];
$grandTotal = 0;
$discountPercentage = 50;
$discountAmount = 0;

$result = $conn->query("SELECT * FROM upi_details ORDER BY updated_at DESC LIMIT 1");
$upiData = $result->fetch_assoc() ?? ['upi_id' => 'default@upi', 'receiver_name' => 'Default Name'];
$upi_id = $upiData['upi_id'];
$receiver_name = $upiData['receiver_name'];

$fullName = $_SESSION['user']['name'] ?? 'Guest';
$phone = $_SESSION['user']['phone'] ?? 'N/A';
$userEmail = $_SESSION['user']['email'] ?? 'test@example.com';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['utr_number'])) {
    $transaction_id = $_POST['utr_number'] ?? '';
    $total_amount = 0;

    if (empty($transaction_id) || strlen($transaction_id) != 12 || !ctype_digit($transaction_id)) {
        die("Invalid transaction ID");
    }

    $items = [];
    foreach ($cart as $item) {
        $price = cleanNumber($item['price']);
        $quantity = cleanNumber($item['quantity']);
        $items[] = ['name' => $item['name'], 'quantity' => $quantity];
        $total_amount += $price * $quantity;
    }

    $items_json = json_encode($items);

    $stmt = $conn->prepare("INSERT INTO orders (name, phone, items, total_amount, transaction_id) VALUES (?, ?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("sssis", $fullName, $phone, $items_json, $total_amount, $transaction_id);
        if ($stmt->execute()) {
            foreach ($cart as $item) {
                $productName = $item['name'];
                $quantityOrdered = cleanNumber($item['quantity']);
                $updateStmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE name = ? AND stock >= ?");
                if ($updateStmt) {
                    $updateStmt->bind_param("isi", $quantityOrdered, $productName, $quantityOrdered);
                    $updateStmt->execute();
                    $updateStmt->close();
                }
            }

            $_SESSION['transaction_id'] = $transaction_id;
            $_SESSION['utr_verified'] = true;
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Database query preparation failed.";
    }
}

if (isset($_GET['download']) && $_GET['download'] == 'true' && isset($_SESSION['utr_verified']) && $_SESSION['utr_verified']) {
    require 'vendor/autoload.php';
    $pdfName = 'Invoice_' . time() . '.pdf';
    $pdfPath = __DIR__ . '/pdf_invoices/' . $pdfName;

    $pdf = new \Mpdf\Mpdf();
    $html = "<h2>SivaMadhu Crackers - Invoice</h2>";
    $html .= "<p><strong>Customer Name:</strong> $fullName<br>";
    $html .= "<strong>Phone:</strong> $phone<br>";
    $html .= "<strong>Transaction ID:</strong> {$_SESSION['transaction_id']}</p>";
    $html .= "<table border='1' cellpadding='5'><tr><th>Product</th><th>Qty</th><th>Price</th><th>Total</th></tr>";

    $subtotal = 0;
    foreach ($cart as $item) {
        $price = cleanNumber($item['price']);
        $qty = cleanNumber($item['quantity']);
        $total = $price * $qty;
        $subtotal += $total;
        $html .= "<tr><td>{$item['name']}</td><td>$qty</td><td>₹$price</td><td>₹$total</td></tr>";
    }
    $html .= "</table><br><strong>Subtotal: ₹$subtotal</strong><br>";

    if ($subtotal >= 3000) {
        $discount = ($subtotal * $discountPercentage) / 100;
        $final = $subtotal - $discount;
        $html .= "<strong>Discount: ₹$discount</strong><br><strong>Total: ₹$final</strong>";
    } else {
        $final = $subtotal;
        $html .= "<strong>Total: ₹$final</strong>";
    }

    $pdf->WriteHTML($html);
    $pdf->Output($pdfPath, \Mpdf\Output\Destination::FILE);

    // Email
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.example.com'; // Your SMTP
        $mail->SMTPAuth = true;
        $mail->Username = 'your@email.com';
        $mail->Password = 'yourpassword';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('your@email.com', 'SivaMadhu Crackers');
        $mail->addAddress($userEmail, $fullName);
        $mail->Subject = 'Your Invoice';
        $mail->Body = 'Please find attached your invoice.';
        $mail->addAttachment($pdfPath);

        $mail->send();
        unset($_SESSION['cart']);
        unset($_SESSION['utr_verified']);
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . basename($pdfPath) . '"');
        readfile($pdfPath);
        exit;
    } catch (Exception $e) {
        echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
