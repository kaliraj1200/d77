<?php
session_start();
if (!isset($_SESSION['payment_success']) || !$_SESSION['payment_success']) {
    header("Location: index.php");
    exit;
}

$cart = $_SESSION['cart'] ?? [];
$transaction_id = $_SESSION['transaction_id'] ?? 'N/A';
$fullName = $_SESSION['user']['name'] ?? 'Guest';
$phone = $_SESSION['user']['phone'] ?? 'N/A';
$date = date('d-m-Y H:i:s');

$grandTotal = 0;
$discount = 0;
$finalTotal = 0;
$discountPercentage = 50;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Download Invoice</title>
    <script src="code/jspdf.umd.min.js"></script>
    <style>
        body { font-family: Arial; text-align: center; padding: 40px; }
        button { padding: 10px 20px; font-size: 16px; }
    </style>
</head>
<body>

<h2>Payment Successful ✅</h2>
<p>Transaction ID: <strong><?= htmlspecialchars($transaction_id); ?></strong></p>
<p>Click the button below to download your invoice.</p>
<button onclick="generatePDF()">Download Invoice</button>

<script>
    async function generatePDF() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        doc.setFontSize(18);
        doc.text("Invoice", 90, 20);
        doc.setFontSize(12);
        doc.text("Customer Name: <?= $fullName ?>", 20, 30);
        doc.text("Phone: <?= $phone ?>", 20, 37);
        doc.text("Transaction ID: <?= $transaction_id ?>", 20, 44);
        doc.text("Date: <?= $date ?>", 20, 51);

        doc.autoTable({
            head: [['Product', 'Price', 'Qty', 'Total']],
            body: [
                <?php
                foreach ($cart as $item) {
                    $price = preg_replace('/[^0-9.]/', '', $item['price']);
                    $qty = $item['quantity'];
                    $total = $price * $qty;
                    $grandTotal += $total;
                    echo "['" . addslashes($item['name']) . "', '₹$price', '$qty', '₹$total'],";
                }
                ?>
            ],
            startY: 60,
        });

        <?php if ($grandTotal >= 3000) {
            $discount = ($grandTotal * $discountPercentage) / 100;
            $finalTotal = $grandTotal - $discount;
        } else {
            $finalTotal = $grandTotal;
        } ?>

        doc.setFontSize(12);
        doc.text("Subtotal: ₹<?= number_format($grandTotal, 2) ?>", 130, doc.lastAutoTable.finalY + 10);
        <?php if ($discount > 0) { ?>
        doc.text("Discount (<?= $discountPercentage ?>%): -₹<?= number_format($discount, 2) ?>", 130, doc.lastAutoTable.finalY + 17);
        <?php } ?>
        doc.text("Grand Total: ₹<?= number_format($finalTotal, 2) ?>", 130, doc.lastAutoTable.finalY + <?= ($discount > 0) ? 24 : 17 ?>);

        doc.save("Invoice_<?= $transaction_id ?>.pdf");

        // ✅ Optional: clear cart after download
        setTimeout(() => {
            window.location.href = "clear_cart.php"; 
        }, 1500);
    }
</script>

<script src="code/jspdf.plugin.autotable.min.js"></script>
</body>
</html>
