<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"content="width=device-width,initial-scale=1.0">
        <title>Cracker Shop</title>
        <link rel="stylesheet" href="css/p.css">
    </head>
    <body>
        <!--header sec-->
        <header class="header">
            <center>
            </center>
        <nav>
    <a href="index.php">Home</a>
    <a href="product.php">Products</a>
    <a href="cart.php">Cart</a>
    <a href="about.php">About</a>
    <a href="contact.php">Contact</a>
        </nav>
        </header>
    <section class="grid-section">
    <h2>Price List</h2>
    <div class="grid-container">
    <?php
      
      $products = [
          ["image" => "img/price-4.jpg", "name" => "Page no : 1"],
          ["image" => "img/price-3.jpg", "name" => "Page no : 2"],
          ["image" => "img/price-1.jpg", "name" => "Page no : 3"],
          ["image" => "img/price-2.jpg", "name" => "Page no : 4"],
      ];
      foreach ($products as $product) {
        echo "<div class='grid-item'>";
        echo "<img src='{$product['image']}' alt='{$product['name']}'>";
        echo "<h3>{$product['name']}</h3>";
        echo "</div>";
    }
    ?>
  </div>
</section>
<style>
    
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: Arial, sans-serif;
  line-height: 1.6;
  background-color: #f9f9f9;
  color: #333333; 
  padding: 10px;
}

header {
  text-align: center;
  padding: 20px 0;
  background-color: #990000;
  color: #FFFFFF; 
}

header h1 {
  font-size: 1.8rem;
}

main {
  max-width: 800px;
  margin: 20px auto;
  background: #ffece6;
  padding: 15px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  border-radius: 5px;
}


.header {
  background-color: #990000;
  color: white;
  padding: 20px 50px;
  text-align: right;
}

.header nav {
  margin-top: 10px;
  font-size: 1.5rem;
}

.header nav a {
  color: #FF7F11; 
  text-decoration: none;
  margin: 0 15px;
  font-size: 18px;
}

.header nav a:hover {
  text-decoration: underline;
  color: #FFFFFF; 
}


.grid-section {
  padding: 20px;
  text-align: center;
}

.grid-section h2 {
  margin-bottom: 20px;
  color: #990000;
}

.grid-container {
  display: grid;
  grid-template-columns: repeat(1, 1fr);
  gap: 20px;
  justify-content: center;
  margin: 0 auto;
  max-width: 600px;
}

.grid-item {
  background-color: #fff;
  border: 1px solid #990000;
  border-radius: 5px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  text-align: center;
  padding: 10px;
}

.grid-item img {
  max-width: 100%;
  border-bottom: 1px solid #990000;
  margin-bottom: 10px;
}

.grid-item h3 {
  margin: 10px 0;
  font-size: 18px;
  color: #FF7F11; 
}

</style>
</body>
</html>