<?php
session_start();
require 'config.php';


function cleanNumber($num) {
    return preg_replace('/[^0-9.]/', '', $num) ?: 0;
}


$cart = $_SESSION['cart'] ?? [];
$grandTotal = 0;
$discountAmount = 0;
$discountPercentage = 10;


$result = $conn->query("SELECT * FROM upi_details ORDER BY updated_at DESC LIMIT 1");
$upiData = $result->fetch_assoc() ?? ['upi_id' => 'default@upi', 'receiver_name' => 'Default Name'];
$upi_id = $upiData['upi_id'];
$receiver_name = $upiData['receiver_name'];


$fullName = $_SESSION['user']['name'] ?? 'Guest';
$phone = $_SESSION['user']['phone'] ?? 'N/A';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $transaction_id = $_POST['utr_number'] ?? '';
    $total_amount = 0;

    if (empty($transaction_id) || strlen($transaction_id) != 12) {
        die("Invalid transaction ID");
    }


    $items = [];
    foreach ($cart as $item) {
        $items[] = [
            'name' => $item['name'],
            'quantity' => $item['quantity']
        ];
        $total_amount += cleanNumber($item['price']) * cleanNumber($item['quantity']);
    }

    $items_json = json_encode($items);


    $stmt = $conn->prepare("INSERT INTO orders (name, phone, items, total_amount, transaction_id) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssis", $fullName, $phone, $items_json, $total_amount, $transaction_id);

    if ($stmt->execute()) {

        unset($_SESSION['cart']); 
        $_SESSION['order_success'] = true;

        header("Location: admin_orders.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
