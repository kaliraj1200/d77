<?php
session_start();
$conn = new mysqli("localhost", "root", "", "fireworks_store");


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$settingsQuery = $conn->query("SELECT * FROM settings WHERE id=1");
$settings = $settingsQuery->fetch_assoc() ?? [];


$shop_name = $settings['shop_name'] ?? "Default Shop Name";
$address = $settings['address'] ?? "Default Address";
$phone = $settings['phone'] ?? "0000000000";
$footer_text = $settings['footer_text'] ?? "© 2025 Default Shop. All rights reserved.";


$slideshowQuery = $conn->query("SELECT image FROM slideshow ORDER BY id DESC LIMIT 3");
$slideshow = [];
while ($row = $slideshowQuery->fetch_assoc()) {
    $slideshow[] = $row['image'];
}
if (empty($slideshow)) {
    $slideshow = ["IMG/default1.webp", "IMG/default2.webp", "IMG/default3.webp"];
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cracker Shop - Home</title>
    <link rel="stylesheet" href="Css/index.css">
    <style>
        .cracker-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: transparent;
            overflow: hidden;
            pointer-events: none;
            z-index: 0;
        }
        .container {
            position: relative;
            z-index: 2;
        }
        .cracker {
            position: absolute;
            width: 4px;
            height: 20px;
            background: var(--rocket-color, orange);
            bottom: 0;
            left: 50%;
            animation: launch 1s ease-out forwards, explode 1s ease-out 1s forwards;
        }
        .spark {
            position: absolute;
            width: 6px;
            height: 6px;
            background: radial-gradient(circle, white 0%, var(--spark-color) 100%);
            border-radius: 50%;
            opacity: 0;
            animation: spark 1s ease-out forwards;
            box-shadow: 0 0 8px var(--spark-color);
        }
        @keyframes launch {
            0% { bottom: 0; }
            100% { bottom: 400px; }
        }
        @keyframes explode {
            0% { opacity: 1; }
            100% { opacity: 0; }
        }
        @keyframes spark {
            0% { opacity: 1; transform: translate(0, 0) scale(1); }
            100% { opacity: 0; transform: translate(var(--x), var(--y)) scale(0); }
        }
    </style>
</head>
<body>

    <!-- GLOBAL MULTI-COLOR FIREWORK ANIMATION -->
    <div class="cracker-container" id="crackerContainer"></div>

    <div class="container">
        <header class="header">
            <center>
                <h1><?= htmlspecialchars($shop_name) ?></h1>
                <h4>Wholesale & retail of quality fancy fireworks, Crackers, Sparklers & Gift boxes</h4>
                <h4><?= htmlspecialchars($address) ?></h4>
                <h4>Phone: <?= htmlspecialchars($phone) ?></h4>
            </center>
            <nav>
                <a href="product.php">Products</a>
                <a href="cart.php">Cart</a>
                <a href="price.php">Price List</a>
                <a href="admin_page.php">Admin</a>
                <a href="about.php">About</a>
                <a href="contact.php">Contact</a>
            </nav>
        </header>

        <marquee class="marquee">🎉 Special Offer: Get 50% OFF on orders above ₹10,000! 🎉</marquee>

        <!-- Slideshow -->
        <section class="slideshow">
            <div class="slides">
                <?php foreach ($slideshow as $slide): ?>
                    <img src="<?= htmlspecialchars($slide) ?>" alt="Slide">
                <?php endforeach; ?>
            </div>
        </section>

        
        <section class="grid-section">
            <h2>Our Products</h2>
            <div class="grid-container">
                <?php
               $products = [
                ["image" => "img/d-2.webp", "name" => "Kids"],
                ["image" => "img/d-3.webp", "name" => "Matches"],
                ["image" => "img/d-4.webp", "name" => "Bombs"],
                ["image" => "img/d5.webp",  "name" => "Bijili"],
                ["image" => "img/d6.webp",  "name" => "Chakkars"],
                ["image" => "img/d7.webp",  "name" => "Fancy"],
                ["image" => "img/d8.webp",  "name" => "Ariel Fancy"],
                ["image" => "img/d9.webp",  "name" => "Rockets"],
                ["image" => "img/d10.webp", "name" => "Sparkels"],
                ["image" => "img/d11.webp", "name" => "Fancy Crackers"],
                ["image" => "img/d12.webp", "name" => "Sky Shot"],
                ["image" => "img/d13.webp", "name" => "Flower Pot"],
            ];
                foreach ($products as $product) {
                    $productName = urlencode($product['name']);
                    $productLink = "product.php?name={$productName}";
                    echo "<div class='grid-item'>";
                    echo "<a href='{$productLink}'>";
                    echo "<img src='{$product['image']}' alt='{$product['name']}'>";
                    echo "<h3>{$product['name']}</h3>";
                    echo "</a>";
                    echo "</div>";
                }
                ?>
            </div>
        </section>

        <footer class="footer">
            <?= htmlspecialchars($footer_text) ?>
        </footer>
    </div>

    <!-- Multi-Color Rockets -->
    <script>
        const rocketColors = ['orange', 'red', 'blue', 'green', 'yellow', 'purple'];
        const sparkColors = ['#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];

        function launchCracker() {
            const container = document.getElementById('crackerContainer');
            const rocketColor = rocketColors[Math.floor(Math.random() * rocketColors.length)];
            const sparkColor = sparkColors[Math.floor(Math.random() * sparkColors.length)];

            const cracker = document.createElement('div');
            cracker.classList.add('cracker');
            cracker.style.left = Math.random() * 90 + '%';
            cracker.style.setProperty('--rocket-color', rocketColor);
            container.appendChild(cracker);

            setTimeout(() => {
                for (let i = 0; i < 25; i++) {
                    const spark = document.createElement('div');
                    spark.classList.add('spark');
                    spark.style.left = '50%';
                    spark.style.bottom = '400px';
                    spark.style.setProperty('--x', `${(Math.random() - 0.5) * 300}px`);
                    spark.style.setProperty('--y', `${(Math.random() - 0.5) * 300}px`);
                    spark.style.setProperty('--spark-color', sparkColor);
                    container.appendChild(spark);
                    setTimeout(() => spark.remove(), 1000);
                }
                cracker.remove();
            }, 1000);
        }
        setInterval(launchCracker, 1200);
    </script>

    <!-- Existing Slideshow CSS -->
    <style>
    .slideshow {
        width: 80%;
        margin: 20px auto;
        overflow: hidden;
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    }
    .slides {
        display: flex;
        width: calc(100% * 3);
        animation: slide 12s infinite;
    }
    .slides img {
        width: 100%;
        object-fit: cover;
        flex-shrink: 0;
    }
    @keyframes slide {
        0% { transform: translateX(0); }
        25% { transform: translateX(0); }
        33% { transform: translateX(-100%); }
       /* 58% { transform: translateX(-100%); }
        66% { transform: translateX(-200%); }
        91% { transform: translateX(-200%); }
        100% { transform: translateX(0); }*/
    }
    @media (max-width: 768px) {
        .slideshow {
            width: 95%;
        }
    }
    </style>

    <!-- Slideshow control -->
    <script>
        let index = 0;
        const slides = document.querySelectorAll('.slides img');
        function showSlide() {
            slides.forEach((img, i) => {
                img.style.display = (i === index) ? 'block' : 'none';
            });
            index = (index + 1) % slides.length;
        }
        showSlide();
        setInterval(showSlide, 3000);
    </script>

</body>
</html>
