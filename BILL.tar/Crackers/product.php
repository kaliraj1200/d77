<?php
session_start();
require 'config.php';


$result = $conn->query("SELECT * FROM products");
$products = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];


$typeResult = $conn->query("SELECT DISTINCT type FROM products");
$types = $typeResult ? $typeResult->fetch_all(MYSQLI_ASSOC) : [];


if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}


$total = 0;
$itemCount = 0;

foreach ($_SESSION['cart'] as $item) {
    $total += $item['price'] * $item['quantity'];
    $itemCount += $item['quantity'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Grid with Search & Filter</title>
    <link rel="stylesheet" href="css/product.css">
    <script>
        function filterProducts(type) {
            let productCards = document.querySelectorAll('.product-card');
            productCards.forEach(card => {
                let productType = card.getAttribute('data-type');
                card.style.display = (type === 'All' || productType === type) ? 'block' : 'none';
            });
        }

        function searchProducts() {
            let input = document.getElementById("searchInput").value.toLowerCase();
            let productCards = document.querySelectorAll(".product-card");

            productCards.forEach(card => {
                let productName = card.querySelector("h3").textContent.toLowerCase();
                card.style.display = productName.includes(input) ? "block" : "none";
            });
        }
    </script>
    <style>
        .stock-label {
            margin-top: 5px;
            font-size: 14px;
            font-weight: bold;
        }
        .low-stock {
            color: orange;
        }
        .out-stock {
            color: red;
        }
    </style>
</head>
<body>
    <header class="header">
        <center>
            <h1>SIVAMADHU CRACKERS</h1>
            <h4>Wholesale & Retail of Quality Fancy Fireworks, Crackers, Sparklers & Gift Boxes</h4>
            <h4>44/35, BHARATHI NAGAR 2, SATTUR ROAD, SIVAKASI.</h4>
            <h4>Phone: 9489688106</h4>
            <div class="search-container">
                <input type="text" id="searchInput" placeholder="Search products..." onkeyup="searchProducts()">
                <button onclick="searchProducts()">Search</button>
            </div>
        </center>
        <nav class="nav">
            <div class="nav-right">
                <a href="index.php">Home</a>
                <a href="cart.php">Cart</a>
                <a href="price.php">Price List</a>
                <a href="about.php">About</a>
                <a href="contact.php">Contact</a>
            </div>
        </nav>
        <marquee class="marquee">🎉 Special Offer: Get 50% OFF on orders above ₹10,000! 🎉</marquee>
    </header>

    <div class="sidebar">
        <button onclick="filterProducts('All')">All</button>
        <?php foreach ($types as $type): ?>
            <button onclick="filterProducts('<?= htmlspecialchars($type['type']) ?>')">
                <?= htmlspecialchars($type['type']) ?>
            </button>
        <?php endforeach; ?>
    </div>


    
    <main>
        <div class="product-list">
            <?php foreach ($products as $product): ?>
                <div class="product-card" data-id="<?= $product['id'] ?>" data-price="<?= $product['price'] ?>" data-type="<?= $product['type'] ?>">
                    <img src="<?= $product['image'] ?>" alt="<?= $product['name'] ?>">
                    <div class="product-details">
                        <h3><?= $product['name'] ?></h3>
                        <div class="product-info">
                            <div>₹<?= $product['price'] ?></div>
                            <div>Type: <?= $product['type'] ?></div>
                            <!-- Stock label -->
                            <?php if ($product['stock'] <= 0): ?>
                                <div class="stock-label out-stock">Out of Stock</div>
                            <?php elseif ($product['stock'] > 0 && $product['stock'] <= 5): ?>
                                <div class="stock-label low-stock">Low Stock (<?= $product['stock'] ?> left)</div>
                            <?php endif; ?>
                            <!-- Add to cart form -->
                            <?php if ($product['stock'] > 0): ?>
                                <form class="add-to-cart-form" data-id="<?= $product['id'] ?>">
                                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                    <input type="hidden" name="action" value="add">
                                    <label for="quantity_<?= $product['id'] ?>">Qty:</label>
                                    <input type="number" name="quantity" id="quantity_<?= $product['id'] ?>" value="0" min="0" max="<?= $product['stock'] ?>">
                                    <button type="submit">Add to Cart</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="floating-cart">
            <a href="cart.php" id="cartButton">🛒 Total: ₹<?= number_format($total, 2) ?> (<?= $itemCount ?> items)</a>
        </div>
    </main>

    <script>
        function addToCart(e) {
            e.preventDefault();
            let form = this;
            let productId = form.getAttribute("data-id");
            let quantity = form.querySelector("input[name='quantity']").value;
            let button = form.querySelector("button[type='submit']");

            button.disabled = true;
            button.textContent = "Adding...";

            fetch("cart.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({
                    product_id: productId,
                    quantity: quantity,
                    action: "add"
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById("cartButton").innerHTML = `🛒 Total: ₹${data.total} (${data.itemCount} items)`;
                } else {
                    alert("Error adding to cart.");
                }
                button.disabled = false;
                button.textContent = "Add to Cart";
            })
            .catch(error => {
                console.error("Fetch error:", error);
                button.disabled = false;
                button.textContent = "Add to Cart";
            });
        }

        document.querySelectorAll(".add-to-cart-form").forEach(form => {
            form.addEventListener("submit", addToCart);
        });
    </script>
</body>
</html>

<?php $conn->close(); ?>