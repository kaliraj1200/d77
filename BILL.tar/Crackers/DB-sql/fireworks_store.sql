-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 05, 2025 at 08:11 AM
-- Server version: 10.1.39-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fireworks_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `username`, `password`) VALUES
(1, 'admin', '81dc9bdb52d04dc20036dbd8313ed055');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `items` text NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_verified` tinyint(1) DEFAULT '0',
  `status` enum('pending','verified') DEFAULT 'pending',
  `transaction_id` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `name`, `phone`, `items`, `total_amount`, `payment_verified`, `status`, `transaction_id`, `created_at`) VALUES
(1, 'jegathesh', '6383734351', '[{\"name\":\"60 Shot Multi Color\",\"quantity\":\"4\"}]', '16000.00', 0, 'pending', '637281546372', '2025-03-27 11:40:42'),
(2, 'kali', '7256384747', '[{\"name\":\"5\\\" Lakshmi Deluex 1pkt\",\"quantity\":\"4\"},{\"name\":\"4\\\" Mega Lakshmi Deluex 1pkt\",\"quantity\":\"3\"},{\"name\":\"4\\\"  Lakshmi  1pkt\",\"quantity\":\"4\"},{\"name\":\"Flower Pot Special (10 pcs)\",\"quantity\":\"4\"},{\"name\":\"Ashrafi fountain  (3 pcs)\",\"quantity\":\"4\"},{\"name\":\"Teddy  (1 pcs)\",\"quantity\":\"2\"}]', '5900.00', 1, 'verified', '826536837465', '2025-03-27 11:42:17'),
(3, 'karuppasamy', '7364646272', '[{\"name\":\"Ashrafi fountain  (3 pcs)\",\"quantity\":\"70\"}]', '40250.00', 1, 'verified', '735343322451', '2025-03-27 11:43:42'),
(4, 'jegathesh', '6383734351', '[{\"name\":\"4\\\" Mega Lakshmi Deluex 1pkt\",\"quantity\":\"5\"},{\"name\":\"Teddy  (1 pcs)\",\"quantity\":\"6\"},{\"name\":\"Peacock Deluxe  (1 pcs)\",\"quantity\":\"3\"}]', '6600.00', 1, 'verified', '343447665243', '2025-03-28 06:22:05'),
(5, 'jegathesh', '6383734351', '[{\"name\":\"4\\\"  Lakshmi  1pkt\",\"quantity\":\"12\"},{\"name\":\"Teddy  (1 pcs)\",\"quantity\":\"3\"},{\"name\":\"Siren (3 pcs)\",\"quantity\":\"4\"},{\"name\":\"Ground Chakkar Big (25 Pcs)\",\"quantity\":\"3\"}]', '6030.00', 1, 'verified', '123563674783', '2025-03-28 07:15:12');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `type` varchar(100) NOT NULL,
  `stock` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `image`, `price`, `type`, `stock`) VALUES
(1, '5\" Lakshmi Deluex 1pkt', 'images/1742469986_l3.jpg', '200.00', 'Sound Crackers', 92),
(2, '4\" Mega Lakshmi Deluex 1pkt', 'images/1742470024_l1.jpg', '180.00', 'Sound Crackers', 92),
(4, '4\"  Lakshmi  1pkt', 'images/1742470121_l3.jpg', '90.00', 'Sound Crackers', 184),
(5, '4\" Gold Lakshmi  1pkt', 'images/1742470166_l2.jpg', '175.00', 'Sound Crackers', 13),
(6, '2 3/4 Bird', 'images/1742470194_k1.jpg', '75.00', 'Sound Crackers', 100),
(7, 'Flower pot small (10 pcs)', 'images/1742470235_f2.jpg', '225.00', 'Flower Pot', 100),
(8, 'Flower pot Big (10 pcs)', 'images/1742470273_f1.jpg', '275.00', 'Flower Pot', 97),
(9, 'Flower Pot Special (10 pcs)', 'images/1742470412_f8.jpg', '350.00', 'Flower Pot', 96),
(10, 'Flower Deluex (5 pcs)', 'images/1742470531_FD-3.jpg', '925.00', 'Flower Pot', 96),
(11, 'Flower pot Deluex (10 pcs)', 'images/1742470617_FA-4.jpg', '480.00', 'Flower Pot', 100),
(12, 'Tri Color Fountain (5 pcs)', 'images/1742470647_f5.jpg', '1000.00', 'Flower Pot', 100),
(13, 'Ashrafi fountain  (3 pcs)', 'images/1742470696_AS-1.jpg', '575.00', 'Fancy Shower', 26),
(14, 'Teddy  (1 pcs)', 'images/1742470759_AS-3.jpg', '250.00', 'Fancy Shower', 86),
(15, 'Bees (1 pcs)', 'images/1742470805_AS-4.jpg', '200.00', 'Fancy Shower', 100),
(16, 'Queen Shower  (1 pcs)', 'images/1742470864_ash5.jpg', '300.00', 'Fancy Shower', 100),
(17, 'Peacock (1 pcs)', 'images/1742471069_PEC-1.jpg', '800.00', 'Fancy Shower', 85),
(18, 'Party Shower  (1 pcs)', 'images/1742471150_s1.jpg', '450.00', 'Fancy Shower', 100),
(19, 'Peacock Deluxe  (1 pcs)', 'images/1742471200_p1.jpg', '1400.00', 'Fancy Shower', 97),
(20, 'Siren (3 pcs)', 'images/1742471234_SI-1.jpg', '750.00', 'Fancy Shower', 96),
(21, 'Photo Flash (5 pcs)', 'images/1742471269_PF-1.jpg', '250.00', 'Fancy Shower', 115),
(22, 'Nick junior (1 Pcs)', 'images/1742471306_f7.jpg', '110.00', 'Fancy Shower', 100),
(23, 'Ashrafi Pops  (5 pcs)', 'images/1742471374_POP-1.jpg', '175.00', 'Fancy Shower', 100),
(30, 'Ground Chakkar Big (25 Pcs)', 'images/1742803474_ch3.jpg', '400.00', 'Ground Chakkars', 89),
(32, 'Ground Chakkar Big Special (10 Pcs)', 'images/1742803570_ch2.jpg', '350.00', 'Ground Chakkars', 100),
(33, 'Chakkar Deluxe (10 Pcs)', 'images/1742803644_ch5.jpg', '600.00', 'Ground Chakkars', 100),
(36, 'Colour Changing Butterfly (10 Pcs)', 'images/1742803819_butter1.jpg', '550.00', 'Ground Chakkars', 100),
(37, 'Bambara (10 Pcs)', 'images/1742803850_ch6.jpg', '600.00', 'Ground Chakkars', 88),
(38, 'Wire Chakkar (10 Pcs)', 'images/1742803898_ch7.jpg', '650.00', 'Ground Chakkars', 100),
(40, 'Water Falls Candle (5 pcs)', 'images/1742804090_WFP-1.jpg', '900.00', 'Fancy', 100),
(46, 'Bat & Ball', 'images/1742804676_BAT-BALL.jpg', '1200.00', 'Fancy', 100),
(51, 'Bullet Bombs (10 pcs)', 'images/1742805158_BOMB-1.jpg', '125.00', 'Bombs', 100),
(52, 'Atom Bombs Green (10 pcs)', 'images/1742805289_BOMA-2.jpg', '250.00', 'Bombs', 100),
(53, 'Hydra Bombs Green (10 pcs)', 'images/1742805410_BOMH-3.jpg', '400.00', 'Bombs', 100),
(55, 'Digital Bombs (10 pcs)', 'images/1742805644_BOMD-7.jpg', '1000.00', 'Bombs', 100),
(56, 'Money in the Bank (1 pcs)', 'images/1742805698_MB-1.jpg', '800.00', 'Bombs', 100),
(57, 'Paper Bomb (1/4 Kg)', 'images/1742805740_BOMH-08.jpg', '225.00', 'Bombs', 100),
(58, 'Paper Bomb (1/2 Kg)', 'images/1742805822_BOMH-8.jpg', '450.00', 'Bombs', 100),
(59, 'Cartoon (10 pcs)', 'images/1742805909_CAR-1.jpg', '100.00', 'Kids Noveltiles', 100),
(60, 'Kit Kat (10 pcs)', 'images/1742805950_KIT-1.jpg', '100.00', 'Kids Noveltiles', 100),
(61, 'Snake Cartoons', 'images/1742806013_CARS-2.jpg', '100.00', 'Kids Noveltiles', 100),
(62, 'Tin Tin (10 pcs)', 'images/1742806070_TIN-1.jpg', '125.00', 'Kids Noveltiles', 100),
(64, 'Roll Caps', 'images/1742806355_ROLL-1.jpg', '375.00', 'Kids Noveltiles', 100),
(68, 'Bingo (5 pcs)', 'images/1742806647_BINGO-1.jpg', '750.00', 'Fancy', 100),
(69, 'Agni Bomb Red(10 pcs)', 'images/1742902114_BOMX-6.jpg', '800.00', 'Bombs', 100),
(70, 'Lolli Pop (5 pcs)', 'images/1742902167_LOL-1.jpg', '1200.00', 'Fancy', 100),
(71, 'Vivo Torch (3 pcs)', 'images/1742902244_ST-2.jpg', '600.00', 'Fancy', 100),
(72, 'Mega Torch (3 pcs)', 'images/1742902297_MT-1.jpg', '600.00', 'Fancy', 100),
(73, 'Colour Smoke (3 pcs)', 'images/1742902364_SOMK-1.jpg', '750.00', 'Fancy', 100),
(74, 'Popcorn Candles (5 pcs)', 'images/1742902417_PP-1.jpg', '900.00', 'Fancy', 100),
(75, '4 x 4 Wheel(1 pcs)', 'images/1742902510_ch8.jpg', '75.00', 'Ground Chakkars', 100),
(76, 'Helecopter (5 Pcs)', 'images/1742902592_he1.jpg', '500.00', 'Ground Chakkars', 100),
(77, 'Disco Wheel (5 Pcs)', 'images/1742902681_ch4.jpg', '450.00', 'Ground Chakkars', 100),
(78, 'Ground Chakkar Big (10 Pcs)', 'images/1742902799_ch1.jpg', '175.00', 'Ground Chakkars', 100),
(79, 'Gold Coin  (1 pcs)', 'images/1742902890_AS-2.jpg', '250.00', 'Fancy Shower', 100),
(81, 'Fancy (1 pcs)', 'images/1742986776_SS-2.jpg', '200.00', 'Sky Shot', 100),
(82, 'Fancy (1 pcs)', 'images/1742986816_SS-4.jpg', '500.00', 'Sky Shot', 100),
(83, 'Fancy (1 pcs)', 'images/1742986925_SS-5.jpg', '1400.00', 'Sky Shot', 100),
(84, 'Fancy (1 pcs)', 'images/1742986999_SS-3.jpg', '1600.00', 'Sky Shot', 100),
(85, 'Fancy (1 pcs)', 'images/1742987048_SS-6.jpg', '300.00', 'Sky Shot', 100),
(86, '7 Shot Color (5 Pcs)', 'images/1742987122_7S-1.jpg', '375.00', 'Sky Shot', 100),
(87, '25 Shot Multi Color', 'images/1742987647_25S-1.jpg', '2000.00', 'Sky Shot', 100),
(88, '12 Star Creckling &Color', 'images/1742987764_KING-1.jpg', '900.00', 'Sky Shot', 100),
(89, '60 Shot Multi Color', 'images/1742987843_60S-2.jpg', '4000.00', 'Sky Shot', 96),
(90, '60 Shot Color', 'images/1742987890_60S-1.jpg', '4500.00', 'Sky Shot', 100),
(100, '7cm Electrical Sparkles (10 pcs)', 'images/1743073404_EL-1.jpg', '50.00', 'Sparklers', 100),
(101, '7cm Colour Sparkles (10 pcs)', 'images/1743073502_EC-2 - Copy.jpg', '55.00', 'Sparklers', 100),
(103, '7cm Red Sparkles (10 pcs)', 'images/1743073586_ER-4.jpg', '60.00', 'Sparklers', 100),
(104, '10cm Electric Sparkles (10 pcs)', 'images/1743073658_EL10-5.jpg', '90.00', 'Sparklers', 100),
(105, '10cm Crockling Sparklers', 'images/1743073791_ES10-6.jpg', '95.00', 'Sparklers', 100),
(106, '10cm Green Sparkles (10 pcs)', 'images/1743073852_EG-7.jpg', '110.00', 'Sparklers', 100),
(107, '10cm Red Sparkles (10 pcs)', 'images/1743073918_ERED-8.jpg', '110.00', 'Sparklers', 100),
(108, '15cm Electrical Sparkles (10 pcs)', 'images/1743074220_EE-9.jpg', '175.00', 'Sparklers', 100),
(109, '15cm Colour Sparkles (10 pcs)', 'images/1743074279_EC-10.jpg', '190.00', 'Sparklers', 100),
(110, '15cm Green Sparkles (10 pcs)', 'images/1743074383_EGREEN-11.jpg', '210.00', 'Sparklers', 100),
(111, '15cm Red Sparkles (10 pcs)', 'images/1743075482_E10RED-12.jpg', '210.00', 'Sparklers', 100),
(112, '7cm Green Sparkles (10 pcs)', 'images/1743156550_ES-3.jpg', '60.00', 'Sparklers', 100),
(113, 'Deluxe', 'images/1743828433_MAT-1.jpg', '325.00', 'Sparklers', 100),
(114, 'Super Deluxe', 'images/1743828493_MAT-2.jpg', '375.00', 'Sparklers', 100),
(115, 'Lamba', 'images/1743828535_MAT-4.jpg', '675.00', 'Sparklers', 100),
(116, 'Mega Deluxe', 'images/1743828572_MAT-3.jpg', '1100.00', 'Sparklers', 100),
(117, '120 Shot Multi Color', 'images/1743828631_120S-1.jpg', '8500.00', 'Sky Shot', 100),
(118, 'Red Bijili  (50 Pcs)', 'images/1743830136_BJ-1.jpg', '75.00', 'Sound Crackers', 100),
(119, 'Red Bijili  (100 Pcs)', 'images/1743830204_BJ-3.jpg', '150.00', 'Sound Crackers', 100),
(120, 'Gold Bijili (100 Pcs)', 'images/1743830312_BJ-4.jpg', '175.00', 'Sound Crackers', 100),
(121, 'Stripped Bijili (100 Pcs)', 'images/1743830373_BJ-2.jpg', '175.00', 'Sound Crackers', 100),
(122, 'Rocket Bomb (10 pcs)', 'images/1743830736_ROCK-1.jpg', '300.00', 'Fancy', 100),
(123, 'Lunik Rocket (10 pcs)', 'images/1743830787_ROCKL-3.jpg', '500.00', 'Fancy', 100),
(124, 'Music Rocket (5 pcs)', 'images/1743830826_ROCKM-2.jpg', '425.00', 'Fancy', 100),
(125, 'Sky Whistling Rocket (10 pcs)', 'images/1743830858_ROCKCSK-4.jpg', '750.00', 'Fancy', 100);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `shop_name` varchar(255) NOT NULL,
  `address` text,
  `phone` varchar(20) NOT NULL,
  `footer_text` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `shop_name`, `address`, `phone`, `footer_text`) VALUES
(1, 'SIVAMADHU CRACKERS', '44/BHARATHI NAGAR 2, SATTUR ROAD,SIVAKASI', '9876543210', 'SIVAMADHU CRACKERS');

-- --------------------------------------------------------

--
-- Table structure for table `slideshow`
--

CREATE TABLE `slideshow` (
  `id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slideshow`
--

INSERT INTO `slideshow` (`id`, `image`) VALUES
(1, 'IMG/d--1.webp'),
(2, 'IMG/d--2.webp'),
(3, 'IMG/d--3.webp'),
(4, 'IMG/18.jpeg'),
(5, 'IMG/4.jpeg'),
(6, 'IMG/6.jpeg'),
(7, 'IMG/18.jpeg'),
(8, 'IMG/3.jpeg'),
(9, 'IMG/4.jpeg'),
(10, 'IMG/3 - Copy.jpeg'),
(11, 'IMG/4 - Copy.jpeg'),
(12, 'IMG/4.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `upi_details`
--

CREATE TABLE `upi_details` (
  `id` int(11) NOT NULL,
  `upi_id` varchar(50) NOT NULL,
  `receiver_name` varchar(100) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upi_details`
--

INSERT INTO `upi_details` (`id`, `upi_id`, `receiver_name`, `updated_at`) VALUES
(1, 'c.kaliraj2005@oksbi', 'KALIRAJ C', '2025-03-28 10:38:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(255) NOT NULL,
  `cityVillage` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `area` varchar(255) NOT NULL,
  `building` varchar(255) NOT NULL,
  `landmark` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `cityVillage`, `district`, `pincode`, `phone`, `area`, `building`, `landmark`, `created_at`) VALUES
(9, 'kali', 'sivakasi', 'Virudhunagar', '626125', '7256384747', 'sivakasi', '111', 'sivakasi', '2025-03-27 11:42:06'),
(10, 'karuppasamy', 'sivakasi', 'Vellore', '626125', '7364646272', 'sivakasi', '222', 'sivakasi', '2025-03-27 11:43:29'),
(11, 'jegathesh', 'SRIVI', 'Virudhunagar', '626125', '6383734351', 'perumalpatti', '444', 'srivilliputhur', '2025-03-28 06:21:31'),
(12, 'jegathesh', 'sivakasi', 'Virudhunagar', '626125', '6383734351', 'perumalpatti', '106', 'srivilliputhur', '2025-03-28 07:12:56');

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE `visitors` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `visit_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visitors`
--

INSERT INTO `visitors` (`id`, `ip_address`, `visit_time`) VALUES
(1, '<visitor_ip>', '2025-03-12 06:36:38');

-- --------------------------------------------------------

--
-- Table structure for table `visitor_logs`
--

CREATE TABLE `visitor_logs` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `visit_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visitor_logs`
--

INSERT INTO `visitor_logs` (`id`, `ip_address`, `visit_time`) VALUES
(1, '::1', '2025-02-27 08:49:16'),
(2, '::1', '2025-02-27 09:25:22'),
(3, '::1', '2025-03-04 05:26:11'),
(4, '::1', '2025-03-04 05:29:22'),
(5, '::1', '2025-03-04 05:32:18'),
(6, '::1', '2025-03-04 05:40:26'),
(7, '::1', '2025-03-04 05:40:49'),
(8, '::1', '2025-03-04 06:56:24'),
(9, '::1', '2025-03-04 06:59:26'),
(10, '::1', '2025-03-04 07:04:19'),
(11, '::1', '2025-03-04 10:48:19'),
(12, '::1', '2025-03-04 11:29:12'),
(13, '::1', '2025-03-04 11:29:26'),
(14, '::1', '2025-03-04 11:33:28'),
(15, '::1', '2025-03-04 11:38:33'),
(16, '::1', '2025-03-04 11:38:38'),
(17, '::1', '2025-03-04 11:38:45'),
(18, '::1', '2025-03-05 10:45:15'),
(19, '::1', '2025-03-05 10:46:40'),
(20, '::1', '2025-03-05 10:50:24'),
(21, '::1', '2025-03-05 10:50:45'),
(22, '::1', '2025-03-05 10:54:51'),
(23, '::1', '2025-03-05 11:05:23'),
(24, '::1', '2025-03-05 11:08:48'),
(25, '::1', '2025-03-05 11:10:36'),
(26, '::1', '2025-03-06 07:54:50'),
(27, '::1', '2025-03-06 08:56:19'),
(28, '::1', '2025-03-06 08:56:24'),
(29, '::1', '2025-03-06 08:56:35'),
(30, '::1', '2025-03-06 08:56:37'),
(31, '::1', '2025-03-06 08:59:00'),
(32, '::1', '2025-03-06 09:00:15'),
(33, '::1', '2025-03-06 09:03:53'),
(34, '::1', '2025-03-12 04:26:21'),
(35, '::1', '2025-03-12 04:26:25'),
(36, '::1', '2025-03-12 04:34:08'),
(37, '::1', '2025-03-12 04:38:51'),
(38, '::1', '2025-03-12 04:42:59'),
(39, '::1', '2025-03-12 04:43:11'),
(40, '::1', '2025-03-12 04:46:24'),
(41, '::1', '2025-03-12 04:47:35'),
(42, '::1', '2025-03-12 05:01:43'),
(43, '::1', '2025-03-12 05:01:46'),
(44, '::1', '2025-03-12 05:02:46'),
(45, '::1', '2025-03-12 05:03:10'),
(46, '::1', '2025-03-12 05:03:20'),
(47, '::1', '2025-03-12 05:03:49'),
(48, '::1', '2025-03-12 05:05:10'),
(49, '::1', '2025-03-12 05:11:56'),
(50, '::1', '2025-03-12 05:44:19'),
(51, NULL, '2025-03-12 06:40:18'),
(52, NULL, '2025-03-12 06:40:21'),
(53, NULL, '2025-03-12 06:40:22'),
(54, NULL, '2025-03-12 06:40:22'),
(55, NULL, '2025-03-12 06:40:22'),
(56, NULL, '2025-03-12 06:40:22'),
(57, NULL, '2025-03-12 06:40:22'),
(58, NULL, '2025-03-12 06:40:23'),
(59, NULL, '2025-03-12 06:40:23'),
(60, NULL, '2025-03-12 06:40:23'),
(61, NULL, '2025-03-12 06:42:30'),
(62, NULL, '2025-03-12 06:42:31'),
(63, NULL, '2025-03-12 06:42:31'),
(64, NULL, '2025-03-12 06:42:31'),
(65, NULL, '2025-03-12 06:42:31'),
(66, NULL, '2025-03-12 06:42:31'),
(67, NULL, '2025-03-12 06:42:32'),
(68, NULL, '2025-03-12 06:42:32'),
(69, NULL, '2025-03-12 06:42:32'),
(70, NULL, '2025-03-12 06:42:32'),
(71, NULL, '2025-03-12 06:42:32'),
(72, NULL, '2025-03-12 06:42:33'),
(73, NULL, '2025-03-12 06:42:33'),
(74, NULL, '2025-03-12 06:42:33'),
(75, NULL, '2025-03-12 06:42:34'),
(76, NULL, '2025-03-12 06:42:35'),
(77, NULL, '2025-03-12 06:42:35'),
(78, NULL, '2025-03-12 06:42:35'),
(79, NULL, '2025-03-12 06:42:35'),
(80, NULL, '2025-03-12 06:42:35'),
(81, NULL, '2025-03-12 06:43:04'),
(82, NULL, '2025-03-12 06:43:06'),
(83, NULL, '2025-03-12 06:43:06'),
(84, NULL, '2025-03-12 06:43:06'),
(85, NULL, '2025-03-12 06:43:07'),
(86, NULL, '2025-03-12 06:43:07'),
(87, NULL, '2025-03-12 06:43:07'),
(88, NULL, '2025-03-12 06:43:08'),
(89, NULL, '2025-03-12 06:43:44'),
(90, NULL, '2025-03-12 06:43:44'),
(91, NULL, '2025-03-12 06:43:45'),
(92, NULL, '2025-03-12 06:43:45'),
(93, NULL, '2025-03-12 06:43:45'),
(94, NULL, '2025-03-12 06:43:45'),
(95, NULL, '2025-03-12 06:43:45'),
(96, NULL, '2025-03-12 06:43:46'),
(97, NULL, '2025-03-12 06:43:46'),
(98, NULL, '2025-03-12 06:44:28'),
(99, NULL, '2025-03-12 06:44:48'),
(100, NULL, '2025-03-12 06:45:51'),
(101, NULL, '2025-03-12 06:46:17'),
(102, NULL, '2025-03-12 06:47:41'),
(103, NULL, '2025-03-12 06:50:07'),
(104, NULL, '2025-03-13 10:55:21'),
(105, '::1', '2025-03-13 10:57:03'),
(106, NULL, '2025-03-13 11:16:30'),
(107, NULL, '2025-03-13 11:17:20'),
(108, NULL, '2025-03-13 11:43:16'),
(109, NULL, '2025-03-13 11:44:53'),
(110, '::1', '2025-03-14 08:00:08'),
(111, '::1', '2025-03-14 08:05:10'),
(112, NULL, '2025-03-14 08:11:52'),
(113, NULL, '2025-03-14 08:12:01'),
(114, NULL, '2025-03-14 08:12:15'),
(115, NULL, '2025-03-14 08:12:40'),
(116, NULL, '2025-03-14 08:14:24'),
(117, NULL, '2025-03-14 08:14:39'),
(118, NULL, '2025-03-14 08:14:51'),
(119, NULL, '2025-03-14 08:16:16'),
(120, NULL, '2025-03-14 08:17:46'),
(121, NULL, '2025-03-14 08:17:49'),
(122, NULL, '2025-03-14 08:17:56'),
(123, NULL, '2025-03-14 08:18:06'),
(124, NULL, '2025-03-14 08:18:10'),
(125, NULL, '2025-03-14 08:19:27'),
(126, NULL, '2025-03-14 08:21:22'),
(127, NULL, '2025-03-14 08:21:40'),
(128, NULL, '2025-03-14 08:22:13'),
(129, NULL, '2025-03-14 08:22:39'),
(130, '::1', '2025-03-14 08:24:17'),
(131, NULL, '2025-03-14 08:25:37'),
(132, NULL, '2025-03-14 08:25:42'),
(133, NULL, '2025-03-14 08:40:05'),
(134, NULL, '2025-03-17 11:01:03'),
(135, NULL, '2025-03-17 11:02:12'),
(136, NULL, '2025-03-17 11:03:53'),
(137, NULL, '2025-03-18 11:05:39'),
(138, NULL, '2025-03-18 11:08:09'),
(139, NULL, '2025-03-18 11:08:44'),
(140, NULL, '2025-03-18 11:11:29'),
(141, NULL, '2025-03-18 11:13:48'),
(142, NULL, '2025-03-18 11:33:26'),
(143, NULL, '2025-03-18 11:39:52'),
(144, NULL, '2025-03-18 11:50:54'),
(145, NULL, '2025-03-20 05:03:33'),
(146, NULL, '2025-03-20 06:07:24'),
(147, NULL, '2025-03-20 06:09:11'),
(148, NULL, '2025-03-20 06:11:37'),
(149, NULL, '2025-03-20 06:47:42'),
(150, NULL, '2025-03-20 06:47:50'),
(151, NULL, '2025-03-20 06:47:56'),
(152, NULL, '2025-03-20 06:48:05'),
(153, NULL, '2025-03-20 06:48:16'),
(154, NULL, '2025-03-20 06:48:23'),
(155, NULL, '2025-03-20 06:48:27'),
(156, NULL, '2025-03-20 06:50:34'),
(157, NULL, '2025-03-20 11:14:25'),
(158, NULL, '2025-03-20 11:14:40'),
(159, NULL, '2025-03-20 11:41:12'),
(160, NULL, '2025-03-20 11:42:43'),
(161, NULL, '2025-03-24 07:50:53'),
(162, NULL, '2025-03-24 08:48:09'),
(163, NULL, '2025-03-24 08:48:37'),
(164, NULL, '2025-03-24 08:50:20'),
(165, NULL, '2025-03-24 08:59:37'),
(166, NULL, '2025-03-24 09:00:34'),
(167, NULL, '2025-03-24 10:51:09'),
(168, NULL, '2025-03-24 10:51:17'),
(169, NULL, '2025-03-24 10:51:25'),
(170, NULL, '2025-03-24 10:51:33'),
(171, NULL, '2025-03-24 10:53:54'),
(172, NULL, '2025-03-24 10:54:12'),
(173, NULL, '2025-03-25 11:16:13'),
(174, NULL, '2025-03-25 11:17:54'),
(175, NULL, '2025-03-25 11:19:34'),
(176, NULL, '2025-03-26 10:48:58'),
(177, NULL, '2025-03-26 10:50:04'),
(178, NULL, '2025-03-26 10:50:05'),
(179, NULL, '2025-03-26 10:52:27'),
(180, NULL, '2025-03-26 11:22:13'),
(181, NULL, '2025-03-26 11:22:46'),
(182, NULL, '2025-03-27 10:54:20'),
(183, NULL, '2025-03-27 11:12:44'),
(184, NULL, '2025-03-27 11:38:44'),
(185, NULL, '2025-03-27 11:38:54'),
(186, NULL, '2025-03-27 11:39:10'),
(187, NULL, '2025-03-27 11:43:50'),
(188, NULL, '2025-03-27 11:45:46'),
(189, NULL, '2025-03-27 11:46:06'),
(190, NULL, '2025-03-27 11:46:58'),
(191, NULL, '2025-03-27 11:47:03'),
(192, NULL, '2025-03-27 11:47:08'),
(193, NULL, '2025-03-27 11:47:40'),
(194, NULL, '2025-03-27 11:47:48'),
(195, NULL, '2025-03-27 11:47:57'),
(196, NULL, '2025-03-28 05:28:30'),
(197, NULL, '2025-03-28 05:28:35'),
(198, NULL, '2025-03-28 05:31:10'),
(199, NULL, '2025-03-28 06:01:25'),
(200, NULL, '2025-03-28 06:02:20'),
(201, NULL, '2025-03-28 06:22:47'),
(202, NULL, '2025-03-28 06:23:34'),
(203, NULL, '2025-03-28 06:33:12'),
(204, NULL, '2025-03-28 06:35:06'),
(205, NULL, '2025-03-28 06:50:47'),
(206, NULL, '2025-03-28 06:55:48'),
(207, NULL, '2025-03-28 10:06:10'),
(208, NULL, '2025-03-28 10:07:35'),
(209, NULL, '2025-03-28 10:09:41'),
(210, NULL, '2025-03-28 10:25:55'),
(211, NULL, '2025-04-05 04:39:41'),
(212, NULL, '2025-04-05 04:40:43'),
(213, NULL, '2025-04-05 04:44:53'),
(214, NULL, '2025-04-05 04:50:37'),
(215, NULL, '2025-04-05 05:09:57'),
(216, NULL, '2025-04-05 05:19:42'),
(217, NULL, '2025-04-05 05:23:59'),
(218, NULL, '2025-04-05 05:27:42'),
(219, NULL, '2025-04-05 05:35:25'),
(220, NULL, '2025-04-05 05:35:28'),
(221, NULL, '2025-04-05 05:35:33'),
(222, NULL, '2025-04-05 05:35:36'),
(223, NULL, '2025-04-05 05:35:39'),
(224, NULL, '2025-04-05 05:35:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slideshow`
--
ALTER TABLE `slideshow`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `upi_details`
--
ALTER TABLE `upi_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visitors`
--
ALTER TABLE `visitors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visitor_logs`
--
ALTER TABLE `visitor_logs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT for table `slideshow`
--
ALTER TABLE `slideshow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `upi_details`
--
ALTER TABLE `upi_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `visitors`
--
ALTER TABLE `visitors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `visitor_logs`
--
ALTER TABLE `visitor_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=225;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
