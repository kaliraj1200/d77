<?php
$host = "127.0.0.1"; 
$username = "root";
$password = ""; 
$database = "fireworks_store";

try {
   
    $conn = new mysqli($host, $username, $password, $database);

   
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

   
    $conn->set_charset("utf8mb4");

   
    mysqli_options($conn, MYSQLI_OPT_CONNECT_TIMEOUT, 10);

} catch (Exception $e) {
    die("Database error: " . $e->getMessage());
}
?>
