<?php
session_start();
require 'config.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && isset($_POST['order_id'])) {
        $order_id = intval($_POST['order_id']);
        if ($_POST['action'] == 'verify') {
            $stmt = $conn->prepare("UPDATE orders SET payment_verified = 1, status = 'verified' WHERE id = ?");
            if ($stmt) {
                $stmt->bind_param("i", $order_id);
                $stmt->execute();
                $stmt->close();
                $_SESSION['msg'] = "Order ID #$order_id has been verified!";
            } else {
                $_SESSION['msg'] = "Error verifying order: " . $conn->error;
            }
        } elseif ($_POST['action'] == 'delete') {
            $stmt = $conn->prepare("DELETE FROM orders WHERE id = ?");
            if ($stmt) {
                $stmt->bind_param("i", $order_id);
                $stmt->execute();
                $stmt->close();
                $_SESSION['msg'] = "Order ID #$order_id has been deleted!";
            } else {
                $_SESSION['msg'] = "Error deleting order: " . $conn->error;
            }
        }
        $query_string = $_POST['current_query'] ?? '';
        header("Location: " . $_SERVER['PHP_SELF'] . "?$query_string");
        exit();
    }
}


$filter = $_GET['filter'] ?? 'pending';
$date_filter = $_GET['date'] ?? '';
$month_filter = $_GET['month'] ?? '';

$sql = "SELECT * FROM orders WHERE 1=1";


if ($filter == 'verified') {
    $sql .= " AND payment_verified = 1";
} else {
    $sql .= " AND (payment_verified = 0 OR payment_verified IS NULL)";
}


if (!empty($date_filter)) {
    $sql .= " AND DATE(created_at) = '" . $conn->real_escape_string($date_filter) . "'";
} elseif (!empty($month_filter)) {
    $sql .= " AND DATE_FORMAT(created_at, '%Y-%m') = '" . $conn->real_escape_string($month_filter) . "'";
}

$sql .= " ORDER BY created_at DESC";
$result = $conn->query($sql);

if (!$result) {
    die("Database Query Error: " . $conn->error);
}

$current_query = http_build_query([
    'filter' => $filter,
    'date' => $date_filter,
    'month' => $month_filter
]);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Admin Orders Management</title>
    <link rel="stylesheet" href="Css/admin.css">
    <style>

        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        .top-bar {
            background-color: #333;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-bar h2 {
            margin: 0;
            font-size: 24px;
        }

        .top-bar button {
            background-color: #4CAF50;
            color: white;
            padding: 8px 15px;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            margin-left: 10px;
        }

        .top-bar button:hover {
            background-color: #45a049;
        }

        .filter-section {
            background: white;
            padding: 15px 20px;
            margin: 20px;
            border-radius: 6px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .filter-section label {
            margin-right: 10px;
            font-weight: bold;
        }

        h1 {
            text-align: center;
            margin-top: 10px;
        }

        .message {
            text-align: center;
            background: #dff0d8;
            color: #3c763d;
            padding: 10px;
            margin: 15px 20px;
            border-radius: 4px;
            border: 1px solid #d6e9c6;
        }

        table {
            width: 95%;
            margin: 20px auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        table th,
        table td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
            vertical-align: middle;
            cursor: pointer;
        }

        table th {
            background-color: #333;
            color: white;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        .selected-row {
            background-color: #d1ecf1 !important;
        }

        .verify-btn,
        .delete-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 5px;
        }

        .verify-btn {
            background-color: #28a745;
            color: white;
        }

        .verify-btn:hover {
            background-color: #218838;
        }

        .delete-btn {
            background-color: #dc3545;
            color: white;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }
    </style>
</head>

<body>

    <div class="top-bar">
        <h2>Admin Orders Panel</h2>
        <div>
            <button onclick="window.location.href='admin_page.php'">Back to Admin Dashboard</button>
            <button id="header-download-btn" disabled>Download Bill</button>
        </div>
    </div>

    <div class="filter-section">
        <form method="get">
            <label>Filter Orders:</label>
            <select name="filter">
                <option value="pending" <?= $filter == 'pending' ? 'selected' : '' ?>>Pending Orders</option>
                <option value="verified" <?= $filter == 'verified' ? 'selected' : '' ?>>Verified Orders</option>
            </select>

            <label>Date:</label>
            <input type="date" name="date" value="<?= htmlspecialchars($date_filter); ?>">

            <label>Month:</label>
            <input type="month" name="month" value="<?= htmlspecialchars($month_filter); ?>">

            <button type="submit">Apply Filter</button>
            <a href="<?= $_SERVER['PHP_SELF']; ?>" style="padding: 5px 10px; background: #888; color: white; text-decoration: none; border-radius: 5px;">Clear Filters</a>
        </form>
    </div>

    <h1><?= ucfirst($filter) ?> Orders List</h1>

    <?php if (isset($_SESSION['msg'])): ?>
        <div class="message"><?= $_SESSION['msg'];
            unset($_SESSION['msg']); ?></div>
    <?php endif; ?>

    <table id="orders-table">
        <tr>
            <th>Name</th>
            <th>Phone</th>
            <th>Items</th>
            <th>Original Total</th>
            <th>Discount Applied</th>
            <th>Final Amount</th>
            <th>Transaction ID</th>
            <th>Order Placed On</th>
            <th>Actions</th>
        </tr>
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()) {
                $original_total = floatval($row['total_amount']);
                $discount = ($original_total >= 10000) ? $original_total * 0.50 : 0;
                $final_total = $original_total - $discount;
                $order_date = date("Y-m-d H:i:s", strtotime($row['created_at']));
                $order_data = [
                    'name' => $row['name'],
                    'phone' => $row['phone'],
                    'items' => json_decode($row['items'], true),
                    'original_total' => number_format($original_total, 2),
                    'discount' => number_format($discount, 2),
                    'final_total' => number_format($final_total, 2),
                    'transaction_id' => $row['transaction_id'],
                    'order_date' => $order_date
                ];
                ?>
                <tr data-order='<?= json_encode($order_data); ?>'>
                    <td><?= htmlspecialchars($row['name']); ?></td>
                    <td><?= htmlspecialchars($row['phone']); ?></td>
                    <td>
                        <?php
                        foreach ($order_data['items'] as $item) {
                            echo htmlspecialchars($item['name']) . " (Qty: " . htmlspecialchars($item['quantity']) . ")<br>";
                        }
                        ?>
                    </td>
                    <td>₹<?= number_format($original_total, 2); ?></td>
                    <td>₹<?= number_format($discount, 2); ?></td>
                    <td><strong>₹<?= number_format($final_total, 2); ?></strong></td>
                    <td><?= htmlspecialchars($row['transaction_id']); ?></td>
                    <td><?= $order_date; ?></td>
                    <td>
                        <?php if ($filter == 'pending'): ?>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="order_id" value="<?= $row['id']; ?>">
                                <input type="hidden" name="action" value="verify">
                                <input type="hidden" name="current_query" value="<?= htmlspecialchars($current_query); ?>">
                                <button type="submit" class="verify-btn">Verify</button>
                            </form>
                        <?php endif; ?>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="order_id" value="<?= $row['id']; ?>">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="current_query" value="<?= htmlspecialchars($current_query); ?>">
                            <button type="submit" class="delete-btn">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        <?php else: ?>
            <tr>
                <td colspan="9" style="color: red;">No <?= $filter; ?> orders found!</td>
            </tr>
        <?php endif; ?>
    </table>

<script src="code/jspdf.umd.min.js"></script>
<script>
    let selectedOrder = null;
    const tableRows = document.querySelectorAll('#orders-table tr[data-order]');
    const headerBtn = document.getElementById('header-download-btn');

    tableRows.forEach(row => {
        row.addEventListener('click', () => {
            tableRows.forEach(r => r.classList.remove('selected-row'));
            row.classList.add('selected-row');
            selectedOrder = JSON.parse(row.getAttribute('data-order'));
            headerBtn.disabled = false;
        });
    });

    headerBtn.addEventListener('click', () => {
        if (selectedOrder) {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            doc.setFontSize(16);
            doc.text("Order Bill", 80, 20);
            doc.setFontSize(12);
            doc.text("Name: " + selectedOrder.name, 20, 40);
            doc.text("Phone: " + selectedOrder.phone, 20, 50);
            doc.text("Transaction ID: " + selectedOrder.transaction_id, 20, 60);
            doc.text("Order Date: " + selectedOrder.order_date, 20, 70);
            doc.text("--------------------------------------------------", 20, 80);
            let y = 90;
            selectedOrder.items.forEach(item => {
                doc.text(item.name + " (Qty: " + item.quantity + ")", 20, y);
                y += 10;
            });
            doc.text("--------------------------------------------------", 20, y);
            y += 10;
            doc.text("Original Amount: ₹" + selectedOrder.original_total, 20, y);
            y += 10;
            doc.text("Discount Applied: ₹" + selectedOrder.discount, 20, y);
            y += 10;
            doc.text("Final Amount: ₹" + selectedOrder.final_total, 20, y);
            doc.save("order_bill.pdf");
        }
    });
</script>

</body>
</html>
