<?php
session_start();
require 'config.php';


if (isset($_POST['clear_all'])) {
    $conn->query("DELETE FROM users");
    header("Location: admin_user_details.php");
    exit();
}


if (isset($_POST['delete_selected']) && !empty($_POST['user_ids'])) {
    $user_ids = implode(",", array_map('intval', $_POST['user_ids']));
    $conn->query("DELETE FROM users WHERE id IN ($user_ids)");
    header("Location: admin_user_details.php");
    exit();
}


$result = $conn->query("SELECT * FROM users ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details</title>
    <link href="code/bootstrap.min.css" rel="stylesheet">
    <link href="css/admin_user_detail.css" rel="stylesheet">

    <style>
        .header-buttons {
            position: sticky;
            top: 0;
            background: #fff;
            padding: 15px;
            z-index: 999;
            display: flex;
            justify-content: space-between;
            border-bottom: 1px solid #ddd;
        }
    </style>
</head>
<body>

<!-- Sticky Header Buttons -->
<div class="header-buttons">
    <a href="admin_page.php" class="btn btn-primary">Go to Admin Page</a>
    <div>
        <button type="submit" name="delete_selected" form="userForm" class="btn btn-danger">Delete Selected</button>
        <button type="submit" name="clear_all" form="userForm" class="btn btn-warning" onclick="return confirm('Are you sure you want to delete all users?');">Clear All</button>
    </div>
</div>

<!-- Content -->
<div class="container content">
    <h2>User Details</h2>

    <form method="POST" id="userForm">
        <div class="table-container">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th><input type="checkbox" id="select_all"></th>
                        <th>ID</th>
                        <th>Full Name</th>
                        <th>City/Village</th>
                        <th>District</th>
                        <th>Pin Code</th>
                        <th>Phone</th>
                        <th>Area</th>
                        <th>Building</th>
                        <th>Landmark</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><input type="checkbox" name="user_ids[]" value="<?php echo $row['id']; ?>"></td>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['fullName']; ?></td>
                            <td><?php echo $row['cityVillage']; ?></td>
                            <td><?php echo $row['district']; ?></td>
                            <td><?php echo $row['pincode']; ?></td>
                            <td><?php echo $row['phone']; ?></td>
                            <td><?php echo $row['area']; ?></td>
                            <td><?php echo $row['building']; ?></td>
                            <td><?php echo $row['landmark']; ?></td>
                            <td><?php echo $row['created_at']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </form>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const selectAllCheckbox = document.getElementById("select_all");
        const checkboxes = document.querySelectorAll('input[name="user_ids[]"]');

        selectAllCheckbox.addEventListener("click", function () {
            checkboxes.forEach(checkbox => checkbox.checked = selectAllCheckbox.checked);
        });
    });
</script>

</body>
</html>
