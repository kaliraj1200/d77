<?php
session_start();
require 'config.php';

function cleanNumber($num) {
    if (!isset($num) || !is_numeric($num)) {
        return 0;
    }
    return preg_replace('/[^0-9.]/', '', (string)$num) ?: 0;
}

if (!$conn->ping()) {
    $conn->close();
    $conn = new mysqli("localhost", "username", "password", "database_name");
    if ($conn->connect_error) {
        die("Database connection failed: " . $conn->connect_error);
    }
}

$conn->query("SET SESSION wait_timeout = 28800");
$conn->query("SET SESSION interactive_timeout = 28800");

$cart = $_SESSION['cart'] ?? [];
$grandTotal = 0;
$discountAmount = 0;
$discountPercentage = 50;

$result = $conn->query("SELECT * FROM upi_details ORDER BY updated_at DESC LIMIT 1");
$upiData = $result->fetch_assoc() ?? ['upi_id' => 'default@upi', 'receiver_name' => 'Default Name'];
$upi_id = $upiData['upi_id'];
$receiver_name = $upiData['receiver_name'];

$fullName = $_SESSION['user']['name'] ?? 'Guest';
$phone = $_SESSION['user']['phone'] ?? 'N/A';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $transaction_id = $_POST['utr_number'] ?? '';
    $total_amount = 0;

    if (empty($transaction_id) || strlen($transaction_id) != 12 || !ctype_digit($transaction_id)) {
        die("Invalid transaction ID");
    }

    $items = [];
    foreach ($cart as $item) {
        if (!isset($item['price'], $item['quantity'], $item['name'])) {
            continue;
        }

        $price = cleanNumber($item['price']);
        $quantity = cleanNumber($item['quantity']);
        $items[] = ['name' => $item['name'], 'quantity' => $quantity];
        $total_amount += $price * $quantity;
    }

    $items_json = json_encode($items);

    $stmt = $conn->prepare("INSERT INTO orders (name, phone, items, total_amount, transaction_id) VALUES (?, ?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("sssis", $fullName, $phone, $items_json, $total_amount, $transaction_id);
        if ($stmt->execute()) {

            foreach ($cart as $item) {
                if (!isset($item['name'], $item['quantity'])) continue;

                $productName = $item['name'];
                $quantityOrdered = cleanNumber($item['quantity']);

                $updateStmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE name = ? AND stock >= ?");
                if ($updateStmt) {
                    $updateStmt->bind_param("isi", $quantityOrdered, $productName, $quantityOrdered);
                    $updateStmt->execute();
                    $updateStmt->close();
                }
            }

            // unset($_SESSION['cart']); // Cart is preserved for now, not clearing
            $_SESSION['payment_success'] = true;
            $_SESSION['transaction_id'] = $transaction_id;
            header("Location: download_invoice.php"); // ✅ Redirect to invoice page
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Database query preparation failed.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Summary</title>
    <script src="code/qrious.min.js"></script>
    <link rel="stylesheet" type="text/css" href="Css/pay.css">
    <script src="code/jspdf.umd.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="user-details">
            <h3>User Details</h3>
            <p><strong>Name:</strong> <?= htmlspecialchars($fullName); ?></p>
            <p><strong>Phone:</strong> <?= htmlspecialchars($phone); ?></p>
        </div>

        <div class="order-summary">
            <h1>Order Summary</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($cart)) { ?>
                        <tr><td colspan="4">Your cart is empty!</td></tr>
                    <?php } else {
                        foreach ($cart as $item) {
                            $price = cleanNumber($item['price']);
                            $quantity = cleanNumber($item['quantity']);
                            $total = $price * $quantity;
                            $grandTotal += $total;
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($item['name']); ?></td>
                        <td>₹<?= $price; ?></td>
                        <td><?= $quantity; ?></td>
                        <td>₹<?= $total; ?></td>
                    </tr>
                    <?php } } ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3"><strong>Subtotal:</strong></td>
                        <td><strong>₹<?= $grandTotal; ?></strong></td>
                    </tr>
                    <?php if ($grandTotal >= 3000) {
                        $discountAmount = ($grandTotal * $discountPercentage) / 100;
                        $finalTotal = $grandTotal - $discountAmount;
                    ?>
                    <tr>
                        <td colspan="3"><strong>Discount (<?= $discountPercentage; ?>%):</strong></td>
                        <td>-₹<?= number_format($discountAmount, 2); ?></td>
                    </tr>
                    <tr>
                        <td colspan="3"><strong>Grand Total After Discount:</strong></td>
                        <td><strong>₹<?= number_format($finalTotal, 2); ?></strong></td>
                    </tr>
                    <?php } else {
                        $finalTotal = $grandTotal;
                    ?>
                    <tr>
                        <td colspan="4" style="color: red;"><strong>Minimum order ₹3000 required for discount.</strong></td>
                    </tr>
                    <?php } ?>
                </tfoot>
            </table>
        </div>
    </div>

    <center>
        <button onclick="confirmPayment(<?= $finalTotal; ?>)">Pay Now</button>
        <button onclick="goToHome()">Back to Home</button>

        <div id="upi-section" style="display:none;">
            <p>Scan the QR code or click the link below to pay:</p>
            <canvas id="upi-qr"></canvas>
            <p><a id="upi-link" href="#" target="_blank">Pay via UPI</a></p>
        </div>

        <div id="utr-section" style="display:none;">
            <p>Enter UTR (Unique Transaction Reference) Number:</p>
            <form method="POST">
                <input type="text" name="utr_number" id="utr-number" placeholder="Enter 12-digit UTR" required>
                <button type="submit">Verify Payment</button>
            </form>
        </div>
    </center>

<script>
    function confirmPayment(amount) {
        const upiString = `upi://pay?pa=<?= $upi_id; ?>&pn=<?= $receiver_name; ?>&am=${amount}&cu=INR`;
        document.getElementById('upi-section').style.display = 'block';
        document.getElementById('utr-section').style.display = 'block';

        const qr = new QRious({
            element: document.getElementById('upi-qr'),
            value: upiString,
            size: 200
        });
        document.getElementById('upi-link').href = upiString;
    }

    function goToHome() {
        window.location.href = 'index.php';
    }
</script>
</body>
</html>
