<?php
session_start();
unset($_SESSION['cart']);
unset($_SESSION['payment_success']);
unset($_SESSION['transaction_id']);
header("Location: index.php"); 
exit;
?>
