function validateForm() {
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    let errorMessage = document.getElementById("error-message");

    if (username.trim() === "" || password.trim() === "") {
        errorMessage.innerText = "Both fields are required!";
        errorMessage.style.color = "red";
        return false;
    }
    return true;
}
