
<?php
// Start session
session_start();

// Mock database data (Replace with actual database queries)




echo
$products = [

    ['id' => 1, 'name' => '5" Lakshmi Deluxe 1Pkt', 'price' => 200, 'image' => 'IMG/l1.jpg', 'type' => 'Sound Crackers'],
    ['id' => 2, 'name' => '4" Mega Lakshmi Deluxe 1Pkt', 'price' => 180, 'image' => 'IMG/l2.jpg', 'type' => 'Sound Crackers'],
    ['id' => 3, 'name' => '4" Gold Lakshmi  1Pkt', 'price' => 175, 'image' => 'IMG/l3.jpg', 'type' => 'Sound Crackers'],
    ['id' => 4, 'name' => '4" Lakshmi 1Pkt', 'price' => 90, 'image' => 'IMG/LG-3.jpg', 'type' => 'Sound Crackers'],
    ['id' => 5, 'name' => 'Flower pot small (10 pcs)', 'price' => 225, 'image' => 'IMG/f2.jpg', 'type' => 'Flower pot'],
    ['id' => 6, 'name' => 'Flower pot Big (10 pcs)', 'price' => 275, 'image' => 'IMG/f1.jpg', 'type' => 'Flower pot'],
    ['id' => 7, 'name' => 'Flower pot small (10 pcs)', 'price' => 350, 'image' => 'IMG/f2.jpg', 'type' => 'Flower pot'],
    ['id' => 8, 'name' => 'Flower pot small (10 pcs)', 'price' => 480, 'image' => 'IMG/f4.jpg', 'type' => 'Flower pot'],
    ['id' => 9, 'name' => 'Ashrafi fountain  (3 pcs)', 'price' => 575, 'image' => 'IMG/SI-1.jpg', 'type' => 'Fancy Shower Pots'],
    ['id' => 9, 'name' => 'Queen Shower  (1 pcs)', 'price' => 800, 'image' => 'IMG/q.jpg', 'type' => 'Fancy Shower Pots'],
    


];



// Initialize cart if not set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Calculate cart total and item count
$total = array_reduce($_SESSION['cart'], function ($sum, $item) {
    return $sum + $item['price'] * $item['quantity'];
}, 0);

$itemCount = array_reduce($_SESSION['cart'], function ($count, $item) {
    return $count + $item['quantity'];
}, 0);

// Ensure cart starts with 0 if empty
if (empty($_SESSION['cart'])) {
    $itemCount = 0;
    $total = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Grid with Search & Filter</title>
    <link rel="stylesheet" href="css/product.css">


    
    <script>
        function filterProducts(type) {
            let productCards = document.querySelectorAll('.product-card');
            productCards.forEach(card => {
                let productType = card.getAttribute('data-type');
                card.style.display = type === 'All' || productType === type ? 'block' : 'none';
            });
        }
    </script>
    <style>
  .floating-filter-bar {
    position: fixed;
    top: 50%; /* Center vertically */
    left: 10px; /* Adjust distance from the left */
    transform: translateY(-50%); /* Perfect vertical centering */
    width: auto; /* Adjust width based on content */
    background-color: rgba(255, 255, 255, 0.2); /* Semi-transparent white */
    backdrop-filter: blur(5px); /* Adds blur effect */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Light shadow */
    display: flex;
    flex-direction: column; /* Stack buttons vertically */
    padding: 10px;
    border-radius: 10px;
    z-index: 1000;
}

.floating-filter-bar button {
    background-color: rgba(255, 255, 255, 0.3); /* Semi-transparent button */
    border: 1px solid rgba(255, 255, 255, 0.5); /* Light border */
    color: #333;
    padding: 10px 15px;
    margin: 5px 0; /* Vertical spacing between buttons */
    cursor: pointer;
    font-size: 14px;
    border-radius: 5px;
    transition: background-color 0.3s, color 0.3s;
    width: 150px; /* Adjust button width */
    text-align: left; /* Align text to the left */
}

.floating-filter-bar button:hover {
    background-color: rgba(255, 255, 255, 0.5); /* Slightly more visible on hover */
    color: black;
}

/* Adjust main content to prevent overlap */
main {
    margin-left: 170px; /* Push content to the right */
}


</style>

<div class="floating-filter-bar">
    <button onclick="filterProducts('All')">All</button>
    <button onclick="filterProducts('Sound Crackers')">Sound Crackers</button>
    <button onclick="filterProducts('Flower pot')">Flower Pot</button>
    <button onclick="filterProducts('Fancy Shower Pots')">Fancy Shower</button>
    <button onclick="filterProducts('Giftbox')">Giftbox</button>
    <button onclick="filterProducts('Rocket')">Rocket</button>
    <button onclick="filterProducts('Night Cracker')">Night Cracker</button>
    <button onclick="filterProducts('Mini Cracker')">Mini Cracker</button>
</div>

</head>
<body>
<header class="header">

<center>
      
      <h1>SIVAMADHU CRACKERS</h1>
      <h4>Wholesale & retail of quality fancy fireworks,Cracker,Sparkler & Gift boxes
      44/35,BHARATHI NAGAR 2, SATTUR ROAD ,SIVAKASI.</h4>
      <h4>Phone : 9489688106</h4>
    </center>

    <nav class="nav">
        <div class="nav-left"></div> <!-- Empty div to help with centering -->
        
        <div class="search-container">
            <input type="text" id="searchInput" placeholder="Search products..." onkeyup="searchProducts()">
            <button onclick="searchProducts()">Search</button>
        </div>

        <div class="nav-right">
            <a href="index.php">Home</a>
            <a href="checkout.php">Cart</a>
            <a href="price.php">Price List</a>
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
        </div>
    </nav>
</header>
    
<main>
        <div class="product-list">
            <?php foreach ($products as $product): ?>
                <div class="product-card" data-id="<?= $product['id'] ?>" data-price="<?= $product['price'] ?>" data-type="<?= $product['type'] ?>">
                    <img src="<?= $product['image'] ?>" alt="<?= $product['name'] ?>">
                    <div class="product-details">
                        <h3><?= $product['name'] ?></h3>
                        <div class="product-info">
                            <div>₹<?= $product['price'] ?></div>
                            <div>Type: <?= $product['type'] ?></div>
                            <form method="POST" action="cart.php">
                                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                <input type="hidden" name="action" value="add">
                                <label for="quantity_<?= $product['id'] ?>">Qty:</label>
                                <input type="number" name="quantity" id="quantity_<?= $product['id'] ?>" value="0" min="0">
                                <button type="submit">Add to Cart</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="floating-cart">
    <a href="cart.php" id="cartButton" class="disabled">🛒 Total: ₹<?= $total ?> (<?= $itemCount ?> items)</a>
</div>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        updateFloatingCart();

        document.querySelectorAll(".product-card form").forEach(form => {
            form.addEventListener("submit", function (event) {
                event.preventDefault();
                let productCard = this.closest(".product-card");
                let productId = productCard.getAttribute("data-id");
                let productName = productCard.querySelector("h3").innerText;
                let productPrice = parseFloat(productCard.getAttribute("data-price"));
                let quantity = parseInt(this.querySelector("input[name='quantity']").value);

                if (quantity > 0) {
                    addToCart(productId, productName, productPrice, quantity);
                }
            });
        });

        // Redirect to checkout page when clicking on floating cart
        document.querySelector(".floating-cart a").addEventListener("click", function (event) {
            event.preventDefault();
            window.location.href = "checkout.php"; // Change to your checkout page
        });

        function addToCart(id, name, price, quantity) {
            let cart = JSON.parse(localStorage.getItem("cart")) || [];
            let existingItem = cart.find(item => item.id === id);

            if (existingItem) {
                existingItem.quantity += quantity;
            } else {
                cart.push({ id, name, price, quantity });
            }

            localStorage.setItem("cart", JSON.stringify(cart));
            updateFloatingCart();
        }

        function updateFloatingCart() {
            let cart = JSON.parse(localStorage.getItem("cart")) || [];
            let totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
            let totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
            let cartButton = document.getElementById("cartButton");

            cartButton.innerHTML = `🛒 Total: ₹${totalPrice} (${totalItems} items)`;

            if (totalItems > 0) {
                cartButton.classList.remove("disabled");
            } else {
                cartButton.classList.add("disabled");
            }
        }
    });

    function searchProducts() {
        let input = document.getElementById("searchInput").value.toLowerCase();
        let productCards = document.querySelectorAll(".product-card");

        productCards.forEach(card => {
            let productName = card.querySelector("h3").innerText.toLowerCase();
            if (productName.includes(input)) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }
        });
    }
</script>
</html>