
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="css/cart.css">
</head>
<body>
<header class="header">
    <h1>Your Cart</h1>
    <a href="product.php" class="back-button">Back to Product Page</a>
</header>

<main>
    <table class="cart-table">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="cart-items">
            <tr><td colspan="5">Your cart is empty!</td></tr>
        </tbody>
    </table>
    
    <h3 id="grand-total">Grand Total: ₹0</h3>

    <div class="actions">
        <button class="clear-cart" onclick="clearCart()">Clear Cart</button>
        <button class="checkout" onclick="checkout()">Checkout</button>
    </div>
</main>

<script>
    function loadCart() {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        const cartItems = document.getElementById('cart-items');
        const grandTotalElement = document.getElementById('grand-total');
        
        if (cart.length === 0) {
            cartItems.innerHTML = '<tr><td colspan="5">Your cart is empty!</td></tr>';
            grandTotalElement.textContent = 'Grand Total: ₹0';
            return;
        }

        let grandTotal = 0;
        cartItems.innerHTML = cart.map((item, index) => {
            const total = item.price * item.quantity;
            grandTotal += total;
            return `
                <tr>
                    <td>${item.name}</td>
                    <td>₹${item.price}</td>
                    <td>
                        <button onclick="updateQuantity(${index}, -1)">-</button>
                        ${item.quantity}
                        <button onclick="updateQuantity(${index}, 1)">+</button>
                    </td>
                    <td>₹${total}</td>
                    <td><button onclick="removeItem(${index})">Remove</button></td>
                </tr>
            `;
        }).join('');
        
        grandTotalElement.textContent = `Grand Total: ₹${grandTotal}`;
    }

    function clearCart() {
        localStorage.removeItem('cart');
        loadCart();
    }

    function removeItem(index) {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        if (cart[index].quantity > 0) {
            cart[index].quantity -= 1;
            if (cart[index].quantity === 0) {
                cart.splice(index, 1);
            }
        }
        localStorage.setItem('cart', JSON.stringify(cart));
        loadCart();
    }

    function updateQuantity(index, change) {
        let cart = JSON.parse(localStorage.getItem('cart')) || [];
        cart[index].quantity += change;
        if (cart[index].quantity < 0) cart[index].quantity = 0;
        if (cart[index].quantity === 0) cart.splice(index, 1);
        localStorage.setItem('cart', JSON.stringify(cart));
        loadCart();
    }

    function checkout() {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        if (cart.length === 0) {
            alert('Your cart is empty!');
            return;
        }
        
        const grandTotal = cart.reduce((total, item) => total + item.price * item.quantity, 0);
        if (grandTotal < 3000) {
            alert('Your order must be at least ₹3000 to proceed to checkout.');
            return;
        }

        localStorage.setItem('cartCheckout', JSON.stringify(cart));
        window.location.href = 'payment.php';
    }

    document.addEventListener("DOMContentLoaded", loadCart);


    function removeItem(index) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.splice(index, 1); // Completely remove the item from the array
    localStorage.setItem('cart', JSON.stringify(cart));
    loadCart(); // Refresh the cart display
}

</script>
</body>
</html>
