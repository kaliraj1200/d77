<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cracker Shop - Home</title>
  <link rel="stylesheet" href="Css/index.css">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
</head>
<body>

  <!-- Header Section -->
  <header class="header">
    <center>
      
      <h1>SIVAMADHU CRACKERS</h1>
      <h4>Wholesale & retail of quality fancy fireworks,Cracker,Sparkler & Gift boxes
      44/35,BHARATHI NAGAR 2, SATTUR ROAD ,SIVAKASI.</h4>
      <h4>Phone : 9489688106</h4>
    </center>


    <nav>
      <?php
      // Navigation links array
      $navLinks = [
          "product.php" => "Products",
          "checkout.php" => "Cart",
          "price.php" => "Price List",
          "homelogin.php" => "Admin",
          "about.php" => "About",
          "contact.php" => "Contact"
      ];

      // Render navigation links
      foreach ($navLinks as $link => $label) {
          echo "<a href='$link'>$label</a>";
      }
      ?>
    </nav>
  </header>
  <!-- Slideshow Section -->
  <section class="slideshow">
    <div class="slides" id="slides">
      <?php
      // Slideshow images array
      $slides = [
        "IMG/d--1.webp",
        "IMG/d--1.webp",
        "IMG/d--1.webp",
        "IMG/d--1.webp",
    ];
    
      // Render slideshow images
      foreach ($slides as $slide) {
          echo "<img src='$slide' alt='Slide'>";
      }
      ?>
    </div>
  </section>
  <!-- Product Grid Section -->
  <section class="grid-section">
    <h2>Our Products</h2>
    <?php
$products = [
    ["id" => 1, "image" => "img/d-2.webp", "name" => "Product 1"],
    ["id" => 2, "image" => "img/d-3.webp", "name" => "Product 2"],
    ["id" => 3, "image" => "img/d-4.webp", "name" => "Product 3"],
    ["id" => 4, "image" => "img/d5.webp", "name" => "Product 4"],
    ["id" => 5, "image" => "img/d6.webp", "name" => "Product 5"],
    ["id" => 6, "image" => "img/d7.webp", "name" => "Product 6"],
    ["id" => 7, "image" => "img/d8.webp", "name" => "Product 7"],
    ["id" => 8, "image" => "img/d9.webp", "name" => "Product 8"],
    ["id" => 9, "image" => "img/d10.webp", "name" => "Product 9"],
    ["id" => 10, "image" => "img/d11.webp", "name" => "Product 10"],
    ["id" => 11, "image" => "img/d12.webp", "name" => "Product 11"],
    ["id" => 12, "image" => "img/d13.webp", "name" => "Product 12"],
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    /* Grid Container */
    .grid-container {
        display: grid;
        grid-template-columns: repeat(4, 1fr); /* 4 columns */
        grid-template-rows: repeat(3, auto);  /* 3 rows */
        gap: 10px; /* Reduced gap */
        max-width: 800px; /* Reduced grid width */
        margin: auto;
        padding: 10px;
    }
    
    /* Grid Items (Product) */
    .grid-item {
        text-align: center;
        border: 1px solid #ddd;
        padding: 10px; /* Reduced padding */
        border-radius: 5px;
        background: #fff;
        transition: transform 0.2s ease-in-out;
    }
    
    /* Hover Effect */
    .grid-item:hover {
        transform: scale(1.05);
    }

    /* Product Image */
    .grid-item img {
        width: 100%;
        max-width: 120px; /* Reduced image size */
        border-radius: 5px;
    }

    /* Product Name */
    .grid-item h3 {
        margin-top: 8px;
        font-size: 14px; /* Smaller font size */
    }
</style>

</head>
<body>


<!-- Product Grid -->
<div class="grid-container">
    <?php foreach ($products as $product): ?>
        <div class="grid-item">
            <a href="product.php?id=<?= $product['id'] ?>">
                <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
            </a>
            <h3><?= htmlspecialchars($product['name']) ?></h3>
        </div>
    <?php endforeach; ?>
</div>

</body>
</html>


</body>
</html>
<?php
      // Render products
     // foreach ($products as $product) {
       //   echo "<div class='grid-item'>";
         // echo "<img src='{$product['image']}' alt='{$product['name']}'>";
          //echo "<h3>{$product['name']}</h3>";
          //echo "</div>";
      //}
      ?>
    </div>
  </section>

  <!-- Footer Section -->
  <footer class="footer">
    <?php
    echo "<p>&copy; " . date("Y") . " SivaMadhu Cracker Shop. All rights reserved.</p>";
    ?>
  </footer>

  <script>
 let slideIndex = 0;            
 const slides = document.getElementById('slides');
    let index = 0;

    function autoSlide() {
      index++;
      if (index >= 4) index = 0; // Reset index to loop slides
      slides.style.transform = `translateX(${-index * 100}%)`;
    }

    setInterval(autoSlide, 3000); // Change slide every 3 seconds


    document.getElementById("removeHeaderBtn").addEventListener("click", function() {
    document.querySelector(".header").style.display = "none";
        });


        document.addEventListener("click", (e) => {
    const numParticles = 30; // Number of sparks
    for (let i = 0; i < numParticles; i++) {
        createSpark(e.clientX, e.clientY);
    }
});
document.addEventListener("click", (event) => {
    const numParticles = 30; // Number of sparks per click
    for (let i = 0; i < numParticles; i++) {
        createSpark(event.clientX, event.clientY);
    }
});

</script>

</body>
</html>