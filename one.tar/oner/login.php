<?php
session_start();

// Hardcoded credentials for demonstration
$admin_username = "admin";
$admin_password = "123456"; // In real cases, use hashed passwords

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username === $admin_username && $password === $admin_password) {
        $_SESSION['admin_logged_in'] = true;
        header("Location: dashboard.php");
        exit();
    } else {
        echo "<script>alert('Invalid Credentials!'); window.location='homelogin.php';</script>";
    }
}
?>
