<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/dash.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <h2>Admin Panel</h2>
            <nav>
                <ul>
                    <li><a href="product.php">📦 Manage Products</a></li>
                    <li><a href="index.php">🏠 Home Page</a></li>
                    <li><a href="about.php">ℹ️ About Page</a></li>
                    <li><a href="contact.php">📞 Contact Page</a></li>
                    <li><a href="price.php">💰 Pricing Page</a></li>
                    <li><a href="logout.php" class="logout">🚪 Logout</a></li>
                </ul>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <h1>Welcome, Admin!</h1>
            <p>Use the navigation menu to manage your website.</p>

            <div class="dashboard-widgets">
                <div class="widget">
                    <h3>🛍 Total Products</h3>
                    <p>10+ items</p>
                </div>
                <div class="widget">
                    <h3>💰 Total Sales</h3>
                    <p>₹50,000+</p>
                </div>
                <div class="widget">
                    <h3>📦 Pending Orders</h3>
                    <p>5 Orders</p>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
