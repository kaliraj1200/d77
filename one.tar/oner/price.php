<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"content="width=device-width,initial-scale=1.0">
        <title>Cracker Shop</title>
        <link rel="stylesheet" href="css/p.css">
    </head>
    <body>
        <!--header sec-->
        <header class="header">
            <center>
            </center>
        <nav>
    <a href="index.php">Home</a>
    <a href="product.php">Products</a>
    <a href="checkout.php">Cart</a>
    <a href="about.php">About</a>
    <a href="contact.php">Contact</a>
        </nav>
        </header>
    <section class="grid-section">
    <h2>Price List</h2>
    <div class="grid-container">
    <?php
      // Products array
      $products = [
          ["image" => "img/price-4.jpg", "name" => "Page no : 1"],
          ["image" => "img/price-3.jpg", "name" => "Page no : 2"],
          ["image" => "img/price-1.jpg", "name" => "Page no : 3"],
          ["image" => "img/price-2.jpg", "name" => "Page no : 4"],
      ];
      foreach ($products as $product) {
        echo "<div class='grid-item'>";
        echo "<img src='{$product['image']}' alt='{$product['name']}'>";
        echo "<h3>{$product['name']}</h3>";
        echo "</div>";
    }
    ?>
  </div>
</section>
</body>
</html>