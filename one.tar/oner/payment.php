<?php
session_start();

// Check if the cart session is initialized, if not, create it with dummy data
if (!isset($_SESSION['cartForCheckout'])) {
    $_SESSION['cartForCheckout'] = [
        ['name' => 'Product A', 'price' => 1200, 'quantity' => 1],
        ['name' => 'Product B', 'price' => 1800, 'quantity' => 1],
        ['name' => 'Product C', 'price' => 1500, 'quantity' => 1]
    ];
}

// Calculate the grand total
$grandTotal = 0;
foreach ($_SESSION['cartForCheckout'] as $item) {
    $grandTotal += $item['price'] * $item['quantity'];
}

// Function to generate UPI Payment Link dynamically
function generateUPIPaymentLink($amount) {
    $merchantUPI = 'merchant-upi-id@upi'; // Replace with actual UPI ID
    $merchantName = 'MerchantName'; // Replace with business name
    $transactionNote = 'Payment for order';
    $currency = 'INR';

    return "upi://pay?pa={$merchantUPI}&pn={$merchantName}&mc=1234&tid=000000&tn={$transactionNote}&am={$amount}&cu={$currency}";
}

$paymentMessage = "Your order must be at least ₹3000 to proceed with payment.";
$upiPaymentLink = '';
if ($grandTotal >= 3000) {
    $upiPaymentLink = generateUPIPaymentLink($grandTotal);
    $paymentMessage = "UPI payment link and QR code generated.";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Summary</title>
    <link rel="stylesheet" href="Css/pay.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>
</head>
<body>
    <h1>Order Summary</h1>
    <table border="1" width="100%" style="border-collapse: collapse; text-align: center;">
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($_SESSION['cartForCheckout'] as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td>₹<?php echo htmlspecialchars($item['price']); ?></td>
                    <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                    <td>₹<?php echo htmlspecialchars($item['price'] * $item['quantity']); ?></td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td colspan="3" style="text-align: right;"><strong>Grand Total:</strong></td>
                <td><strong>₹<?php echo $grandTotal; ?></strong></td>
            </tr>
        </tbody>
    </table>
    
    <div style="text-align: center; margin-top: 20px;">
        <button onclick="confirmPayment()">Pay Now</button>
        <button onclick="goToHome()">Back to Home</button>
        
        <div id="upi-section" style="display: none; margin-top: 20px;">
            <p>Scan the QR code or click the link below to pay:</p>
            <canvas id="upi-qr"></canvas>
            <p><a id="upi-link" href="<?php echo $upiPaymentLink; ?>" target="_blank">Pay via UPI</a></p>
        </div>
        
        <p><?php echo $paymentMessage; ?></p>
    </div>

    <script>
        function confirmPayment() {
            const upiPaymentLink = "<?php echo $upiPaymentLink; ?>";
            if (upiPaymentLink) {
                document.getElementById('upi-section').style.display = 'block';
                new QRious({ element: document.getElementById('upi-qr'), value: upiPaymentLink, size: 200 });
            } else {
                alert('Your order must be at least ₹3000 to proceed with payment.');
            }
        }
        function goToHome() { window.location.href = 'index.php'; }
    </script>
</body>
</html>
