<?php
$host = "127.0.0.1"; // Use 127.0.0.1 instead of localhost if needed
$username = "root";
$password = ""; // Leave empty if no password is set
$database = "fireworks_store";

try {
    // Create connection
    $conn = new mysqli($host, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    // Set charset to avoid encoding issues
    $conn->set_charset("utf8mb4");

    // Set persistent connection (optional)
    mysqli_options($conn, MYSQLI_OPT_CONNECT_TIMEOUT, 10);

} catch (Exception $e) {
    die("Database error: " . $e->getMessage());
}
?>
