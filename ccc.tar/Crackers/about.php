<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>About Us</title>
  <link rel="stylesheet" href="Css/about.css">
</head>
<body>

<header class="header">
  <center>
    <h1>Welcome to SivaMadhu Cracker Shop</h1>
  </center>
  <nav>
    <a href="index.php">Home</a>
    <a href="product.php">Products</a>
    <a href="checkout.php">Cart</a>
    <a href="price.php">Price List</a>
    <a href="contact.php">Contact</a>
  </nav>
</header>
<style>
  /* General Styles */
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  background: #f9f9f9; /* Soft Neutral */
  color: #333333; /* Charcoal Gray */
  overflow-x: hidden;
}

h1, h2 {
  color: #990000; /* Crimson Red */
  text-align: center;
}

/* Header */
.header {
  background: #990000; /* Crimson Red */
  padding: 20px 50px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
  color: white;
  text-align: right;
}

.header nav a {
  text-decoration: none;
  color: white;
  margin: 0 15px;
  font-size: 18px;
  transition: color 0.3s ease, transform 0.3s ease;
}

.header nav a:hover {
  color: #FF7F11; /* Vibrant Orange */
  transform: scale(1.1);
}

/* About Us Section */
.about-us {
  padding: 40px 20px;
  animation: fadeIn 2s ease-in;
}

.about-us-container {
  display: flex;
  align-items: center;
  justify-content: space-around;
  gap: 20px;
  flex-wrap: wrap;
}

.about-us-container img {
  width: 300px;
  height: auto;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
}

.about-us-content {
  max-width: 600px;
  font-size: 16px;
  line-height: 1.6;
  color: #333333; /* Charcoal Gray */
}

/* Products Section */
.products {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 40px;
  margin-top: 40px;
}

.products div {
  text-align: center;
  animation: zoomIn 2s ease;
}

.products div img {
  width: 200px;
  height: auto;
  border-radius: 15px;
  box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.products div img:hover {
  transform: scale(1.1);
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
}

.products div h2 {
  margin-top: 10px;
  color: #FF7F11; /* Vibrant Orange */
}

/* Animations */
@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes zoomIn {
  from {
    transform: scale(0.8);
    opacity: 0;
  }
  to {
    transform: scale(1);
    opacity: 1;
  }
}

</style>
<div class="main-content">
  <div class="about-us">
    <h1>About Us</h1>
    <div class="about-us-container">
      <img src="IMG/1.jpg" alt="Crackers">
      <div class="about-us-content">
        <p>
          Greetings from Madhu Crackers! We have been in the cracker industry for the past 10 years. 
          It's our pride in supplying our esteemed customers with the best quality crackers at market prices. 
          Our superior quality crackers have earned us many satisfactory and smiling customers and helped us in winning their reputation and trust. 
          We are your lifetime companion in all your memorable moments and give joy & color to all occasions.
        </p>
        <p>
          Our products have carved a niche for their quality & Safety and this has been made possible by ensuring quality control measures right in the organizational processes. 
          Each and every moment in life has to be celebrated and we make your celebrations still more memorable with our Premium Pyro Flower Pots and Sky Filling Aerial Shots.
        </p>
      </div>
    </div>

    <div class="products">
      <div>
        <img src="IMG/2.jpeg" alt="Wholesale">
        <h2>Wholesale</h2>
      </div>
      <div>
        <img src="IMG/3.jpeg" alt="Retail">
        <h2>Retail</h2>
      </div>
    </div>
  </div>
</div>
<!--- Footer section-->
<footer><center> 2010-2024 Madhu Crackers. All Rights Reserved</center></footer>
</body>
</html>
