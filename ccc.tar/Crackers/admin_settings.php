<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Database connection
$conn = new mysqli("localhost", "root", "", "fireworks_store");

// Check connection
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Update settings
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $shop_name = trim($_POST['shop_name']);
    $address = trim($_POST['address']);
    $phone = trim($_POST['phone']);
    $footer_text = trim($_POST['footer_text']);

    // Debugging: Check received POST data
    if (empty($shop_name) || empty($phone)) {
        die("Error: Shop Name and Phone are required.");
    }

    // Debugging: Print received data
    echo "Updating shop settings:<br>";
    echo "Shop Name: $shop_name <br> Address: $address <br> Phone: $phone <br> Footer: $footer_text <br>";

    // Update settings using a prepared statement
    $stmt = $conn->prepare("UPDATE settings SET shop_name=?, address=?, phone=?, footer_text=? WHERE id=1");
    if (!$stmt) {
        die("Prepare Statement Failed: " . $conn->error);
    }

    $stmt->bind_param("ssss", $shop_name, $address, $phone, $footer_text);
    if (!$stmt->execute()) {
        die("Query Execution Failed: " . $stmt->error);
    }
    $stmt->close();

    echo "Settings updated successfully! <br>";

    // Handle Slideshow Image Upload
    if (!empty($_FILES['slideshow']['name'][0])) {
        foreach ($_FILES['slideshow']['tmp_name'] as $index => $tmp_name) {
            if ($_FILES['slideshow']['error'][$index] === UPLOAD_ERR_OK) {
                $filename = "IMG/" . basename($_FILES['slideshow']['name'][$index]);

                if (!move_uploaded_file($tmp_name, $filename)) {
                    die("File Upload Failed: " . $_FILES['slideshow']['name'][$index]);
                }

                // Insert new slideshow image into database
                $stmt = $conn->prepare("INSERT INTO slideshow (image) VALUES (?)");
                if (!$stmt) {
                    die("Prepare Failed for Slideshow Insert: " . $conn->error);
                }

                $stmt->bind_param("s", $filename);
                if (!$stmt->execute()) {
                    die("Slideshow Image Insert Failed: " . $stmt->error);
                }
                $stmt->close();

                echo "Image Uploaded: $filename <br>";
            } else {
                echo "File Upload Error: " . $_FILES['slideshow']['error'][$index] . "<br>";
            }
        }
    }

    // Redirect back to admin page after updating
    echo "<script>alert('Settings updated successfully!'); window.location.href='admin_page.php';</script>";
}

// Get current settings
$result = $conn->query("SELECT * FROM settings WHERE id=1");
if ($result->num_rows > 0) {
    $settings = $result->fetch_assoc();
} else {
    die("No settings found! Please insert default settings in the database.");
}

// Get latest 3 slideshow images
$slideshow = $conn->query("SELECT image FROM slideshow ORDER BY id DESC LIMIT 3");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Settings</title>
    <link rel="stylesheet" href="css/admin_settings.css">
</head>
<body>
    <style>
        /* Center the page */
body {
    font-family: Arial, sans-serif;
    background-color: #f9f9f9; /* Soft Neutral */
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.container {
    background: white;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    width: 400px;
    text-align: center;
}

h2 {
    margin-bottom: 20px;
    color: #990000; /* Crimson Red */
}

form {
    display: flex;
    flex-direction: column;
    align-items: center; /* Center elements inside the form */
}

label {
    text-align: left;
    font-weight: bold;
    margin-top: 10px;
    width: 100%;
    color: #333333; /* Charcoal Gray */
}

input, textarea {
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 5px;
    width: 100%;
}

button {
    background-color: #990000; /* Crimson Red */
    color: white;
    border: none;
    padding: 10px 20px;
    margin-top: 15px;
    border-radius: 5px;
    cursor: pointer;
    transition: 0.3s ease;
    align-self: center; /* Ensure button stays centered */
}

button:hover {
    background-color: #FF7F11; /* Vibrant Orange */
    color: #fff;
}

/* Centering the images */
.image-gallery {
    margin-top: 20px;
    text-align: center;
}

.image-gallery img {
    width: 80px;
    height: 80px;
    margin: 5px;
    border-radius: 5px;
    border: 1px solid #990000; /* Crimson border */
}

    </style>
    <div class="container">
        <h2>Update Shop Settings</h2>
        <form method="post" enctype="multipart/form-data">
            <label>Shop Name:</label>
            <input type="text" name="shop_name" value="<?= htmlspecialchars($settings['shop_name']) ?>" required>

            <label>Address:</label>
            <textarea name="address"><?= htmlspecialchars($settings['address']) ?></textarea>

            <label>Phone:</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($settings['phone']) ?>" required>

            <label>Footer Text:</label>
            <textarea name="footer_text"><?= htmlspecialchars($settings['footer_text']) ?></textarea>

            <label>Slideshow Images:</label>
            <input type="file" name="slideshow[]" multiple>

            <button type="submit">Update</button>
        </form>

        <h3>Latest 3 Slideshow Images</h3>
        <div class="image-gallery">
            <?php while ($row = $slideshow->fetch_assoc()): ?>
                <img src="<?= htmlspecialchars($row['image']) ?>" alt="Slideshow Image" width="150">
            <?php endwhile; ?>
        </div>
    </div>
    <div class="container text-center mt-4">
        <a href="admin_page.php" class="btn btn-primary">Go to Admin Page</a>
    </div>
</body>
</html>
