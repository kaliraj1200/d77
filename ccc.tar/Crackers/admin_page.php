<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "fireworks_store");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$conn->query("INSERT INTO visitor_logs (visit_time) VALUES (NOW())");


$totalVisitors = $conn->query("SELECT COUNT(*) as count FROM visitor_logs")->fetch_assoc()['count'];


$totalSales = $conn->query("SELECT SUM(total_amount) as total FROM orders")->fetch_assoc()['total'] ?? 0;


$totalOrders = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'] ?? 0;


//$pendingOrders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE status = 'Pending'")->fetch_assoc()['count'] ?? 0;


$totalProducts = $conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'] ?? 0;


$query = "SELECT DATE(visit_time) as visit_date, COUNT(*) as visit_count 
          FROM visitor_logs 
          WHERE visit_time >= DATE_SUB(NOW(), INTERVAL 7 DAY)
          GROUP BY DATE(visit_time)";
$result = $conn->query($query);

$dates = [];
$counts = [];

while ($row = $result->fetch_assoc()) {
    $dates[] = $row['visit_date'];
    $counts[] = $row['visit_count'];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
       
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            padding: 0;
        }

        .dashboard-container {
            display: flex;
            height: 100vh;
        }

       
        .sidebar {
            background: #2c3e50;
            color: white;
            padding: 20px;
            width: 250px;
            display: flex;
            flex-direction: column;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            margin: 15px 0;
        }

        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px;
            background: #34495e;
            border-radius: 5px;
            text-align: center;
        }

        .sidebar ul li a:hover {
            background: #1abc9c;
        }

        .main-content {
            flex: 1;
            padding: 20px;
        }

        .dashboard-widgets {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }

        .widget {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            flex: 1;
            text-align: center;
        }

  
        .chart-container {
            width: 100%;
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <h2>Admin Panel</h2>
            <ul>
                <li><a href="admin_products.php">📝 Manage Products</a></li>
                <li><a href="admin_user_details.php">👥 User Details</a></li>
                <li><a href="admin_settings.php">🏠 Home Page</a></li>
                <li><a href="admin_update_upi.php">🏦 UPI-Update</a></li>
                <li><a href="admin_orders.php">🔑 Transaction</a></li>
                <li><a href="logout.php" class="logout">🚪 Logout</a></li>
            </ul>
        </aside>

        <main class="main-content">
            <h1>Welcome, Admin!</h1>
            <p>Manage your website efficiently.</p>

            <div class="dashboard-widgets">
                <div class="widget">
                    <h3>🛍 Total Products</h3>
                    <p><?= $totalProducts ?> items</p>
                </div>
                <div class="widget">
                    <h3>💰 Total Sales</h3>
                    <p>₹<?= number_format($totalSales, 2) ?></p>
                </div>
                <div class="widget">
                    <h3>📦 Total Orders</h3>
                    <p><?= $totalOrders ?> Orders</p>
                </div>
               <!-- <div class="widget">
                    <h3>⏳ Pending Orders</h3>
                    <p><?= $pendingOrders ?> Pending</p>
                </div>-->
                <div class="widget">
                    <h3>👤 Total Visitors</h3>
                    <p><?= $totalVisitors ?> visits</p>
                </div>
            </div>

            <div class="chart-container">
                <canvas id="visitorChart"></canvas>
            </div>

            <script>
                const labels = <?= json_encode($dates) ?>;
                const data = <?= json_encode($counts) ?>;

                const ctx = document.getElementById('visitorChart').getContext('2d');
                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Visitors in the Last 7 Days',
                            data: data,
                            borderColor: 'rgb(54, 162, 235)',
                            backgroundColor: 'rgba(54, 162, 235, 0.4)',
                            borderWidth: 3,
                            pointBackgroundColor: 'rgb(54, 162, 235)',
                            pointRadius: 5,
                            fill: true,
                            tension: 0.4
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: { display: false }
                        },
                        scales: {
                            y: { beginAtZero: true }
                        }
                    }
                });
            </script>
        </main>
    </div>
</body>
</html>
