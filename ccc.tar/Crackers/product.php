<?php
session_start();
require 'config.php'; // Database connection

// Fetch products from the database
$result = $conn->query("SELECT * FROM products");
$products = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

// Fetch unique product types for filtering
$typeResult = $conn->query("SELECT DISTINCT type FROM products");
$types = $typeResult ? $typeResult->fetch_all(MYSQLI_ASSOC) : [];

// Initialize cart if not set
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Calculate cart total and item count
$total = 0;
$itemCount = 0;

foreach ($_SESSION['cart'] as $item) {
    $total += $item['price'] * $item['quantity'];
    $itemCount += $item['quantity'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Grid with Search & Filter</title>
    <link rel="stylesheet" href="css/product.css">
    <script>
        function filterProducts(type) {
            let productCards = document.querySelectorAll('.product-card');
            productCards.forEach(card => {
                let productType = card.getAttribute('data-type');
                card.style.display = (type === 'All' || productType === type) ? 'block' : 'none';
            });
        }

        function searchProducts() {
            let input = document.getElementById("searchInput").value.toLowerCase();
            let productCards = document.querySelectorAll(".product-card");

            productCards.forEach(card => {
                let productName = card.querySelector("h3").textContent.toLowerCase();
                card.style.display = productName.includes(input) ? "block" : "none";
            });
        }
    </script>
    <style>
        .stock-label {
            margin-top: 5px;
            font-size: 14px;
            font-weight: bold;
        }
        .low-stock {
            color: orange;
        }
        .out-stock {
            color: red;
        }
    </style>
</head>
<body>
    <header class="header">
        <center>
            <h1>SIVAMADHU CRACKERS</h1>
            <h4>Wholesale & Retail of Quality Fancy Fireworks, Crackers, Sparklers & Gift Boxes</h4>
            <h4>44/35, BHARATHI NAGAR 2, SATTUR ROAD, SIVAKASI.</h4>
            <h4>Phone: 9489688106</h4>
            <div class="search-container">
                <input type="text" id="searchInput" placeholder="Search products..." onkeyup="searchProducts()">
                <button onclick="searchProducts()">Search</button>
            </div>
        </center>
        <nav class="nav">
            <div class="nav-right">
                <a href="index.php">Home</a>
                <a href="cart.php">Cart</a>
                <a href="price.php">Price List</a>
                <a href="about.php">About</a>
                <a href="contact.php">Contact</a>
            </div>
        </nav>
        <marquee class="marquee">🎉 Special Offer: Get 50% OFF on orders above ₹10,000! 🎉</marquee>
    </header>

    <div class="sidebar">
        <button onclick="filterProducts('All')">All</button>
        <?php foreach ($types as $type): ?>
            <button onclick="filterProducts('<?= htmlspecialchars($type['type']) ?>')">
                <?= htmlspecialchars($type['type']) ?>
            </button>
        <?php endforeach; ?>
    </div>


    <style>
    /* General Reset */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Body */
body {
  font-family: Arial, sans-serif;
  background: linear-gradient(to bottom, #FFF3E4, #F7F7F7); /* Soft Cream to Light Gray */
  color: #2E2E2E; /* Charcoal Gray */
  overflow-x: hidden;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 15px;
}

/* Header Section */
.header {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  background-color: #FF6B35; /* Vibrant Orange */
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  padding: 15px 0;
  z-index: 1000;
  text-align: center;
}

.header h1 {
  color: #FFFFFF; /* White */
  font-size: 24px;
  margin-bottom: 5px;
}

.header h4 {
  font-size: 14px;
  color: #FFF3E4; /* Soft Cream */
}

/* Navigation Bar */
.nav {
  display: flex;
  justify-content: flex-end;
  padding: 10px 20px;
}

.nav-right {
  display: flex;
  gap: 15px;
}

.nav-right a {
  text-decoration: none;
  color: #FFFFFF; /* White */
  padding: 8px 12px;
  font-weight: bold;
  transition: 0.3s;
  border-radius: 5px;
}

.nav-right a:hover {
  background: #D7263D; /* Crimson Red */
  color: white;
}

/* Search Container */
.search-container {
  display: flex;
  justify-content: center;
  margin: 20px 0;
  gap: 10px;
}

.search-container input {
  padding: 8px;
  border: 1px solid #FF6B35; /* Vibrant Orange */
  border-radius: 5px;
  width: 250px;
}

.search-container button {
  padding: 8px 15px;
  border: none;
  background-color: #D7263D; /* Crimson Red */
  color: white;
  cursor: pointer;
  border-radius: 5px;
  transition: 0.3s;
}

.search-container button:hover {
  background-color: #FF6B35; /* Vibrant Orange */
}

/* Sidebar */
.sidebar {
  width: 200px;
  background: #FFF3E4; /* Soft Cream */
  padding: 15px;
  position: fixed;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 20px;
}

.sidebar button {
  width: 150px;
  padding: 10px;
  border: 2px solid #D7263D; /* Crimson Red */
  background: transparent;
  color: #D7263D;
  cursor: pointer;
  font-size: 16px;
  border-radius: 5px;
  transition: 0.3s;
}

.sidebar button:hover {
  background: #D7263D;
  color: white;
}

main {
  margin-left: 220px;
  padding: 20px;
  width: calc(100% - 220px);
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 22%;
}

/* Product List */
.product-list {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  justify-content: center;
  width: 100%;
}

/* Product Card */
.product-card {
  width: 220px;
  border: 1px solid #FF6B35; /* Vibrant Orange */
  border-radius: 5px;
  overflow: hidden;
  padding: 15px;
  background: #F7F7F7; /* Light Gray */
  text-align: center;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.product-card img {
  width: 100%;
  height: auto;
  border-radius: 5px;
}

/* Product Info */
.product-info {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.product-info button {
  padding: 8px 12px;
  background-color: #FF6B35; /* Vibrant Orange */
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: 0.3s;
}

.product-info button:hover {
  background-color: #D7263D; /* Crimson Red */
}

/* Floating Cart */
.floating-cart {
  position: fixed;
  bottom: 20px;
  right: 20px;
  background-color: #FF6B35; /* Vibrant Orange */
  color: white;
  padding: 10px 20px;
  border-radius: 50px;
  cursor: pointer;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  display: flex;
  align-items: center;
  justify-content: center;
}

.floating-cart a {
  text-decoration: none;
  color: white;
}

.floating-cart:hover {
  background-color: #D7263D; /* Crimson Red */
}

/* Responsive Design */
@media (max-width: 768px) {
  .sidebar {
    width: 180px;
  }

  main {
    margin-left: 190px;
    width: calc(100% - 190px);
  }

  .product-card {
    width: 180px;
  }
}

@media (max-width: 576px) {
  .sidebar {
    width: 160px;
  }

  main {
    margin-left: 170px;
    width: calc(100% - 170px);
  }

  .product-card {
    width: 100%;
  }

  .nav {
    flex-direction: column;
    align-items: center;
  }

  .nav-right {
    justify-content: center;
    flex-wrap: wrap;
  }
}

</style>
    <main>
        <div class="product-list">
            <?php foreach ($products as $product): ?>
                <div class="product-card" data-id="<?= $product['id'] ?>" data-price="<?= $product['price'] ?>" data-type="<?= $product['type'] ?>">
                    <img src="<?= $product['image'] ?>" alt="<?= $product['name'] ?>">
                    <div class="product-details">
                        <h3><?= $product['name'] ?></h3>
                        <div class="product-info">
                            <div>₹<?= $product['price'] ?></div>
                            <div>Type: <?= $product['type'] ?></div>
                            <!-- Stock label -->
                            <?php if ($product['stock'] <= 0): ?>
                                <div class="stock-label out-stock">Out of Stock</div>
                            <?php elseif ($product['stock'] > 0 && $product['stock'] <= 5): ?>
                                <div class="stock-label low-stock">Low Stock (<?= $product['stock'] ?> left)</div>
                            <?php endif; ?>
                            <!-- Add to cart form -->
                            <?php if ($product['stock'] > 0): ?>
                                <form class="add-to-cart-form" data-id="<?= $product['id'] ?>">
                                    <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                    <input type="hidden" name="action" value="add">
                                    <label for="quantity_<?= $product['id'] ?>">Qty:</label>
                                    <input type="number" name="quantity" id="quantity_<?= $product['id'] ?>" value="0" min="0" max="<?= $product['stock'] ?>">
                                    <button type="submit">Add to Cart</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="floating-cart">
            <a href="cart.php" id="cartButton">🛒 Total: ₹<?= number_format($total, 2) ?> (<?= $itemCount ?> items)</a>
        </div>
    </main>

    <script>
        function addToCart(e) {
            e.preventDefault();
            let form = this;
            let productId = form.getAttribute("data-id");
            let quantity = form.querySelector("input[name='quantity']").value;
            let button = form.querySelector("button[type='submit']");

            button.disabled = true;
            button.textContent = "Adding...";

            fetch("cart.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({
                    product_id: productId,
                    quantity: quantity,
                    action: "add"
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById("cartButton").innerHTML = `🛒 Total: ₹${data.total} (${data.itemCount} items)`;
                } else {
                    alert("Error adding to cart.");
                }
                button.disabled = false;
                button.textContent = "Add to Cart";
            })
            .catch(error => {
                console.error("Fetch error:", error);
                button.disabled = false;
                button.textContent = "Add to Cart";
            });
        }

        document.querySelectorAll(".add-to-cart-form").forEach(form => {
            form.addEventListener("submit", addToCart);
        });
    </script>
</body>
</html>

<?php $conn->close(); ?>