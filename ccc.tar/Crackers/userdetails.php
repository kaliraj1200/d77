<?php
session_start();
require 'config.php'; // Database connection file

$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $fullName = trim($_POST['fullName']);
    $cityVillage = trim($_POST['cityVillage']);
    $district = trim($_POST['district']);
    $pincode = trim($_POST['pincode']);
    $phone = trim($_POST['phone']);
    $area = trim($_POST['area']);
    $building = trim($_POST['building']);
    $landmark = trim($_POST['landmark']);

    // Validation
    if (empty($fullName)) $errors[] = "Full Name is required.";
    if (empty($cityVillage)) $errors[] = "City/Village is required.";
    if (empty($district) || $district == "Select District") $errors[] = "District is required.";
    if (!preg_match('/^\d{6}$/', $pincode)) $errors[] = "Pin Code must be 6 digits.";
    if (!preg_match('/^\d{10}$/', $phone)) $errors[] = "Phone Number must be 10 digits.";
    if (empty($area)) $errors[] = "Area Name is required.";
    if (empty($building)) $errors[] = "Building/House Number is required.";
    if (empty($landmark)) $errors[] = "Landmark is required.";

    if (empty($errors)) {
        // Insert user details into database
        $stmt = $conn->prepare("INSERT INTO users (fullName, cityVillage, district, pincode, phone, area, building, landmark) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $fullName, $cityVillage, $district, $pincode, $phone, $area, $building, $landmark);

        if ($stmt->execute()) {
            $_SESSION['user_id'] = $conn->insert_id; // Store user ID

            // Store user details in session
            $_SESSION['user'] = [
                'name' => $fullName,
                'phone' => $phone
            ];

            header("Location: payment.php"); // Redirect to payment page
            exit;
        } else {
            $errors[] = "Database error: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details Form</title>
    <link href="code/bootstrap1.min.css" rel="stylesheet">
    <style>
        .error { color: red; }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2>User Details</h2>

        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <?php foreach ($errors as $error): ?>
                    <p><?php echo $error; ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form id="userDetailsForm" method="POST">
            <div class="form-group">
                <label for="fullName">Full Name</label>
                <input type="text" class="form-control" id="fullName" name="fullName" required>
            </div>
            <div class="form-group">
                <label for="cityVillage">City/Village</label>
                <input type="text" class="form-control" id="cityVillage" name="cityVillage" required>
            </div>
            <div class="form-group">
                <label for="district">District Name</label>
                <select class="form-control" id="district" name="district" required>
                    <option value="Select District">Select District</option>
                    <option value="Ariyalur">Ariyalur</option>
        <option value="Chengalpattu">Chengalpattu</option>
        <option value="Chennai">Chennai</option>
        <option value="Coimbatore">Coimbatore</option>
        <option value="Cuddalore">Cuddalore</option>
        <option value="Dharmapuri">Dharmapuri</option>
        <option value="Dindigul">Dindigul</option>
        <option value="Erode">Erode</option>
        <option value="Kallakurichi">Kallakurichi</option>
        <option value="Kanchipuram">Kanchipuram</option>
        <option value="Kanyakumari">Kanyakumari</option>
        <option value="Karur">Karur</option>
        <option value="Krishnagiri">Krishnagiri</option>
        <option value="Madurai">Madurai</option>
        <option value="Mayiladuthurai">Mayiladuthurai</option>
        <option value="Nagapattinam">Nagapattinam</option>
        <option value="Namakkal">Namakkal</option>
        <option value="Nilgiris">Nilgiris</option>
        <option value="Perambalur">Perambalur</option>
        <option value="Pudukkottai">Pudukkottai</option>
        <option value="Ramanathapuram">Ramanathapuram</option>
        <option value="Ranipet">Ranipet</option>
        <option value="Salem">Salem</option>
        <option value="Sivaganga">Sivaganga</option>
        <option value="Tenkasi">Tenkasi</option>
        <option value="Thanjavur">Thanjavur</option>
        <option value="Theni">Theni</option>
        <option value="Thoothukudi">Thoothukudi</option>
        <option value="Tiruchirappalli">Tiruchirappalli</option>
        <option value="Tirunelveli">Tirunelveli</option>
        <option value="Tirupattur">Tirupattur</option>
        <option value="Tiruppur">Tiruppur</option>
        <option value="Tiruvallur">Tiruvallur</option>
        <option value="Tiruvannamalai">Tiruvannamalai</option>
        <option value="Tiruvarur">Tiruvarur</option>
        <option value="Vellore">Vellore</option>
        <option value="Viluppuram">Viluppuram</option>
        <option value="Virudhunagar">Virudhunagar</option>
                </select>
            </div>
            <div class="form-group">
                <label for="pincode">Pin Code</label>
                <input type="text" class="form-control" id="pincode" name="pincode" maxlength="6" required>
                <small class="error" id="pincodeError"></small>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" class="form-control" id="phone" name="phone" maxlength="10" required>
                <small class="error" id="phoneError"></small>
            </div>
            <div class="form-group">
                <label for="area">Area Name</label>
                <input type="text" class="form-control" id="area" name="area" required>
            </div>
            <div class="form-group">
                <label for="building">Building/House Number</label>
                <input type="text" class="form-control" id="building" name="building" required>
            </div>
            <div class="form-group">
                <label for="landmark">Landmark</label>
                <input type="text" class="form-control" id="landmark" name="landmark" required>
            </div>

            <button type="submit" class="btn btn-primary" id="payNowButton">Pay Now</button>
        </form>
    </div>
    <script>
    document.addEventListener("DOMContentLoaded", function () {
        const form = document.getElementById("userDetailsForm");
        const payNowButton = document.getElementById("payNowButton");
        const inputs = form.querySelectorAll("input, select");

        function validateForm() {
            let isValid = true;

            inputs.forEach(input => {
                if (input.value.trim() === "" || (input.id === "district" && input.value === "Select District")) {
                    isValid = false;
                }
            });

            payNowButton.disabled = !isValid; // Enable if all fields are filled
        }

        // Attach event listeners to all inputs
        inputs.forEach(input => {
            input.addEventListener("input", validateForm);
            input.addEventListener("change", validateForm);
        });

        // Initial check on page load
        validateForm();
    });
</script>

</body>
</html>
