<?php
session_start();
require 'config.php'; // Ensure this file contains your database connection details

function cleanNumber($num) {
    if (!isset($num) || !is_numeric($num)) {
        return 0;
    }
    return preg_replace('/[^0-9.]/', '', (string)$num) ?: 0;
}

// Ensure MySQL connection is active
if (!$conn->ping()) {
    $conn->close();
    $conn = new mysqli("localhost", "username", "password", "database_name");
    if ($conn->connect_error) {
        die("Database connection failed: " . $conn->connect_error);
    }
}

// Set session timeout settings
$conn->query("SET SESSION wait_timeout = 28800");
$conn->query("SET SESSION interactive_timeout = 28800");

$cart = $_SESSION['cart'] ?? [];
$grandTotal = 0;
$discountAmount = 0;
$discountPercentage = 50;

// Fetch latest UPI details
$result = $conn->query("SELECT * FROM upi_details ORDER BY updated_at DESC LIMIT 1");
$upiData = $result->fetch_assoc() ?? ['upi_id' => 'default@upi', 'receiver_name' => 'Default Name'];
$upi_id = $upiData['upi_id'];
$receiver_name = $upiData['receiver_name'];

// Fetch user details from session
$fullName = $_SESSION['user']['name'] ?? 'Guest';
$phone = $_SESSION['user']['phone'] ?? 'N/A';

// Handle form POST (UTR verification)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $transaction_id = $_POST['utr_number'] ?? '';
    $total_amount = 0;

    if (empty($transaction_id) || strlen($transaction_id) != 12 || !ctype_digit($transaction_id)) {
        die("Invalid transaction ID");
    }

    // Prepare cart data
    $items = [];
    foreach ($cart as $item) {
        if (!isset($item['price'], $item['quantity'], $item['name'])) {
            continue;
        }
        
        $price = cleanNumber($item['price']);
        $quantity = cleanNumber($item['quantity']);
        $items[] = ['name' => $item['name'], 'quantity' => $quantity];
        $total_amount += $price * $quantity;
    }

    $items_json = json_encode($items);

    // Insert into orders table
    $stmt = $conn->prepare("INSERT INTO orders (name, phone, items, total_amount, transaction_id) VALUES (?, ?, ?, ?, ?)");
    if ($stmt) {
        $stmt->bind_param("sssis", $fullName, $phone, $items_json, $total_amount, $transaction_id);
        if ($stmt->execute()) {
            // Reduce stock now
            foreach ($cart as $item) {
                if (!isset($item['name'], $item['quantity'])) continue;

                $productName = $item['name'];
                $quantityOrdered = cleanNumber($item['quantity']);
                
                // Update stock (assumes 'products' table has 'name' and 'stock' columns)
                $updateStmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE name = ? AND stock >= ?");
                if ($updateStmt) {
                    $updateStmt->bind_param("isi", $quantityOrdered, $productName, $quantityOrdered);
                    $updateStmt->execute();
                    $updateStmt->close();
                }
            }

            unset($_SESSION['cart']); // Clear cart
            $_SESSION['payment_success'] = true; // Set flag for invoice download
            $_SESSION['transaction_id'] = $transaction_id; // Pass UTR to JS
            header("Location: " . $_SERVER['PHP_SELF']); // Reload page
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Database query preparation failed.";
    }
} 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Summary</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>
    <link rel="stylesheet" type="text/css" href="Css/pay.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="user-details">
            <h3>User Details</h3>
            <p><strong>Name:</strong> <?= htmlspecialchars($fullName); ?></p>
            <p><strong>Phone:</strong> <?= htmlspecialchars($phone); ?></p>
        </div>
        
        <div class="order-summary">
            <h1>Order Summary</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($cart)) { ?>
                        <tr><td colspan="4">Your cart is empty!</td></tr>
                    <?php } else { 
                        foreach ($cart as $item) { 
                            $price = cleanNumber($item['price']);
                            $quantity = cleanNumber($item['quantity']);
                            $total = $price * $quantity;
                            $grandTotal += $total;
                    ?>
                    <tr>
                        <td><?= htmlspecialchars($item['name']); ?></td>
                        <td>₹<?= $price; ?></td>
                        <td><?= $quantity; ?></td>
                        <td>₹<?= $total; ?></td>
                    </tr>
                    <?php } } ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3"><strong>Subtotal:</strong></td>
                        <td><strong>₹<?= $grandTotal; ?></strong></td>
                    </tr>
                    <?php if ($grandTotal >= 3000) { 
                        $discountAmount = ($grandTotal * $discountPercentage) / 100;
                        $finalTotal = $grandTotal - $discountAmount;
                    ?>
                    <tr>
                        <td colspan="3"><strong>Discount (<?= $discountPercentage; ?>%):</strong></td>
                        <td>-₹<?= number_format($discountAmount, 2); ?></td>
                    </tr>
                    <tr>
                        <td colspan="3"><strong>Grand Total After Discount:</strong></td>
                        <td><strong>₹<?= number_format($finalTotal, 2); ?></strong></td>
                    </tr>
                    <?php } else { 
                        $finalTotal = $grandTotal;
                    ?>
                    <tr>
                        <td colspan="4" style="color: red;"><strong>Minimum order ₹3000 required for discount.</strong></td>
                    </tr>
                    <?php } ?>
                </tfoot>
            </table>
        </div>
    </div>

    <center>
        <button onclick="confirmPayment(<?= $finalTotal; ?>)">Pay Now</button>
        <button onclick="goToHome()">Back to Home</button>

        <div id="upi-section" style="display:none;">
            <p>Scan the QR code or click the link below to pay:</p>
            <canvas id="upi-qr"></canvas>
            <p><a id="upi-link" href="#" target="_blank">Pay via UPI</a></p>
        </div>

        <div id="utr-section" style="display:none;">
            <p>Enter UTR (Unique Transaction Reference) Number:</p>
            <form method="POST">
                <input type="text" name="utr_number" id="utr-number" placeholder="Enter 12-digit UTR" required>
                <button type="submit">Verify Payment</button>
            </form>
        </div>
    </center>

<script>
    function confirmPayment(amount) {
        const upiString = `upi://pay?pa=<?= $upi_id; ?>&pn=<?= $receiver_name; ?>&am=${amount}&cu=INR`;
        document.getElementById('upi-section').style.display = 'block';
        document.getElementById('utr-section').style.display = 'block';

        const qr = new QRious({
            element: document.getElementById('upi-qr'),
            value: upiString,
            size: 200
        });
        document.getElementById('upi-link').href = upiString;
    }

    function goToHome() {
        window.location.href = 'index.php';
    }

    function downloadInvoice() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();
        const shopName = "SivaMadhu Crackers";
        const customerName = "<?= htmlspecialchars($fullName); ?>";
        const phone = "<?= htmlspecialchars($phone); ?>";
        const billNo = "BILL-<?= $_SESSION['user']['id'] ?? rand(1000,9999); ?>";
        const dateTime = new Date().toLocaleString();
        const transactionID = "<?= $_SESSION['transaction_id'] ?? 'N/A'; ?>";

        let y = 20;
        doc.setFontSize(16);
        doc.text(shopName, 75, y);
        y += 10;
        doc.setFontSize(14);
        doc.text("Invoice / Bill Receipt", 80, y);
        y += 10;

        doc.setFontSize(11);
        doc.text("Bill No: " + billNo, 14, y);
        y += 7;
        doc.text("Date & Time: " + dateTime, 14, y);
        y += 7;
        doc.text("Customer Name: " + customerName, 14, y);
        y += 7;
        doc.text("Phone: " + phone, 14, y);
        y += 7;
        doc.text("Transaction ID: " + transactionID, 14, y);
        y += 10;

        doc.text("Product", 14, y);
        doc.text("Qty", 80, y);
        doc.text("Price", 100, y);
        doc.text("Total", 140, y);
        y += 7;
        doc.line(14, y, 190, y);
        y += 5;

        let cart = <?= json_encode($cart); ?>;
        let subtotal = 0;
        cart.forEach(item => {
            let product = item.name;
            let qty = item.quantity;
            let price = item.price;
            let total = price * qty;
            subtotal += total;
            doc.text(product, 14, y);
            doc.text(qty.toString(), 80, y);
            doc.text("₹" + price, 100, y);
            doc.text("₹" + total, 140, y);
            y += 7;
        });

        y += 5;
        doc.line(14, y, 190, y);
        y += 7;
        doc.text("Subtotal: ₹" + subtotal.toFixed(2), 140, y);
        y += 7;

        <?php if ($grandTotal >= 3000) { ?>
            doc.text("Discount (<?= $discountPercentage; ?>%): -₹<?= number_format($discountAmount, 2); ?>", 140, y);
            y += 7;
            doc.text("Grand Total: ₹<?= number_format($finalTotal, 2); ?>", 140, y);
        <?php } else { ?>
            doc.text("Grand Total: ₹<?= number_format($finalTotal, 2); ?>", 140, y);
        <?php } ?>

        y += 15;
        doc.setFontSize(10);
        doc.text("Thank you for shopping with " + shopName, 70, y);
        doc.save("Invoice_<?= $_SESSION['user']['name'] ?? 'Guest'; ?>.pdf");
    }

    <?php if (isset($_SESSION['payment_success']) && $_SESSION['payment_success'] === true) { ?>
    window.onload = function() {
        downloadInvoice();
        setTimeout(function() {
            window.location.href = 'index.php';
        }, 1500); // Redirect after 1.5 seconds (adjust time as needed)
        <?php unset($_SESSION['payment_success']); unset($_SESSION['transaction_id']); ?>
    }
<?php } ?>
</script>
</body>
</html>

